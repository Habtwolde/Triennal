# Databricks notebook source
# MAGIC %md
# MAGIC Load Excel + derive dropdown options safely

# COMMAND ----------

# MAGIC %pip install -U openpyxl

# COMMAND ----------

# MAGIC %md
# MAGIC Config + paths + auth

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# Cell 1 — Bootstrap (NEW notebook, run this cell only)

import os, re, json, time, textwrap, requests
from pathlib import Path

# -----------------------------
# 1) Paths (same as your baseline)
# -----------------------------
BASE = "/dbfs/FileStore/triennial"
EXCEL = f"{BASE}/Triennial Data Source_Master File of All Submissions_OEPR Ch3 Writers (1).xlsx"
STYLE_PROMPT = f"{BASE}/style_prompt.json"
REFERENCE_DOCX = f"{BASE}/Triennial Data Source_Style Guide for Triennial Report.docx"
LUA_FILTER = f"{BASE}/h2_pagebreak.lua"
OUT_DIR = f"{BASE}/out"
Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

ENDPOINT = "databricks-meta-llama-3-3-70b-instruct"

print("BASE:", BASE)
print("OUT_DIR:", OUT_DIR)
print("ENDPOINT:", ENDPOINT)

# -----------------------------
# 2) Validate required files exist (fail early with clear messages)
# -----------------------------
missing = []
for p in [EXCEL, STYLE_PROMPT, REFERENCE_DOCX]:
    if not Path(p).exists():
        missing.append(p)

if missing:
    raise FileNotFoundError(
        "Missing required file(s) in DBFS. Please confirm these paths exist:\n- " +
        "\n- ".join(missing)
    )

print("✅ Required files found:")
print(" - EXCEL:", EXCEL)
print(" - STYLE_PROMPT:", STYLE_PROMPT)
print(" - REFERENCE_DOCX:", REFERENCE_DOCX)
print(" - LUA_FILTER exists?:", Path(LUA_FILTER).exists())

# -----------------------------
# 3) Databricks notebook-context auth (only for notebook testing)
# -----------------------------
try:
    HOST  = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().get()
    TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
except Exception as e:
    raise RuntimeError(
        "Could not read HOST/TOKEN from notebook context (dbutils). "
        "This must be run inside a Databricks notebook attached to a cluster.\n"
        f"Original error: {e}"
    )

print("✅ HOST acquired:", HOST)

# -----------------------------
# 4) Auth probe (serving endpoints list)
# -----------------------------
try:
    probe = requests.get(
        f"{HOST}/api/2.0/serving-endpoints",
        headers={"Authorization": f"Bearer {TOKEN}"},
        timeout=30
    )
    print("Auth probe status:", probe.status_code)
    if probe.status_code == 401:
        raise RuntimeError("401 Unauthorized. Your notebook identity cannot access serving endpoints.")
    probe.raise_for_status()
except Exception as e:
    raise RuntimeError(
        "Auth probe failed. This means the current notebook identity cannot call the Serving Endpoints API.\n"
        f"Details: {e}"
    )

print("✅ Cell 1 complete: paths + notebook-context auth OK.")


# COMMAND ----------

# Cell 2 — Load Excel + build dropdown options (run this cell only)

import pandas as pd
import re
from pathlib import Path

pd.options.display.max_colwidth = 200

def load_excel(excel_path: str) -> pd.DataFrame:
    # Note: openpyxl is used under the hood for .xlsx
    df = pd.read_excel(excel_path, sheet_name=0)
    df.columns = [str(c).strip() for c in df.columns]
    return df

def resolve_col(df: pd.DataFrame, desired: str) -> str:
    """
    Resolve a column name case-insensitively.
    Raises a clear error if not found.
    """
    if desired in df.columns:
        return desired
    lc = {c.lower(): c for c in df.columns}
    if desired.lower() in lc:
        return lc[desired.lower()]
    # relaxed match: remove spaces
    desired_norm = desired.lower().replace(" ", "")
    for c in df.columns:
        if str(c).lower().replace(" ", "") == desired_norm:
            return c
    raise KeyError(
        f"Could not find a column matching '{desired}'. "
        f"Available columns (first 30): {list(df.columns)[:30]}"
    )

def dropdown_values(df: pd.DataFrame, col: str) -> list[str]:
    col = resolve_col(df, col)
    vals = (
        df[col]
        .dropna()
        .astype(str)
        .map(lambda x: x.strip())
    )
    # remove empties and common placeholders
    vals = [v for v in vals if v and v.lower() not in ("nan", "—")]
    return sorted(set(vals))

# ---- Load ----
df = load_excel(EXCEL)
print("✅ Excel loaded:", df.shape)

# ---- Resolve required columns ----
FIELD_COL = resolve_col(df, "Field")
ACTIVITY_TYPE_COL = resolve_col(df, "Activity Type")

print("✅ FIELD_COL resolved to:", FIELD_COL)
print("✅ ACTIVITY_TYPE_COL resolved to:", ACTIVITY_TYPE_COL)

# ---- Dropdown options ----
field_options = dropdown_values(df, "Field")
activity_type_options = dropdown_values(df, "Activity Type")

print("\nDropdown counts:")
print(" - Fields:", len(field_options))
print(" - Activity Types:", len(activity_type_options))

print("\nSample Fields (first 25):")
print(field_options[:25])

print("\nSample Activity Types (first 25):")
print(activity_type_options[:25])

# COMMAND ----------

# MAGIC %md
# MAGIC Two-filter exact match + card construction boundary check

# COMMAND ----------

# Cell 3 — Apply the two dropdown filters and build cards (SELF-CONTAINED, NO LLM calls)

import re
import pandas as pd

# --- Rebuild CMAP defensively (do not assume Cell 2 state) ---
CANON = [
    "Submitting ICO","Lead ICO","Unique ID","Collaborating ICOs/Agencies/Orgs",
    "Activity Name","Activity Description","Activity Type","Field","Importance",
    "Web address(es)","PMID(s)","Notes","Notes.1"
]

def resolve_map(cols):
    lower = {c.lower(): c for c in cols}
    m = {}
    for want in CANON:
        w = want.lower()
        if w in lower:
            m[want] = lower[w]
            continue
        found = None
        for k in lower:
            if w.replace(" ","") in k.replace(" ",""):
                found = lower[k]
                break
        if found:
            m[want] = found
    return m

CMAP = resolve_map(df.columns)

# --- Filter logic ---
def filter_df(df: pd.DataFrame, field_value: str, activity_type_value: str) -> pd.DataFrame:
    f = df[(df[FIELD_COL] == field_value) & (df[ACTIVITY_TYPE_COL] == activity_type_value)].copy()
    return f.fillna("—")

# --- Helpers copied from baseline ---
def as_str(x):
    if pd.isna(x): return "—"
    s = str(x)
    return s if s.strip() else "—"

def split_urls_from_excel_cell(s: str) -> list[str]:
    if not s or s == "—":
        return []
    out = re.split(r"[;\s,]+", str(s).strip())
    return [p for p in out if p.lower().startswith("http")]

def split_pmids(s: str) -> list[str]:
    if not s or s == "—":
        return []
    return re.findall(r"\b(\d{4,9})\b", str(s))

def make_card(row: pd.Series, cmap: dict) -> dict:
    card = {k: as_str(row.get(cmap.get(k, k), "—")) for k in CANON}
    urls = split_urls_from_excel_cell(card.get("Web address(es)", ""))
    pmids = [f"https://pubmed.ncbi.nlm.nih.gov/{p}/" for p in split_pmids(card.get("PMID(s)", ""))]
    card["_citations"] = [u for u in (urls + pmids) if u]
    return card

# ---- Test selection (same as before) ----
selected_field = "Cancer"
selected_activity_type = "Basic Research"

filtered = filter_df(df, selected_field, selected_activity_type)

print("✅ Filters applied:")
print(" - Field:", selected_field)
print(" - Activity Type:", selected_activity_type)
print("✅ Filtered rows:", len(filtered))

# ---- Preview ----
preview_cols = []
for col in ["Unique ID", "Activity Name", "Submitting ICO", "Lead ICO", "Field", "Activity Type"]:
    preview_cols.append(CMAP.get(col, col))
preview_cols = [c for c in preview_cols if c in filtered.columns]

display(filtered[preview_cols].head(10))

# ---- Build cards + UID index ----
cards = [make_card(r, CMAP) for _, r in filtered.iterrows()]

uid_index = {}
uids_missing = 0
for c in cards:
    uid = c.get("Unique ID", "—")
    if uid and uid != "—":
        uid_index[uid] = c
    else:
        uids_missing += 1

print("\n✅ Cards built:", len(cards))
print("✅ UID index size:", len(uid_index))
print("⚠️ Rows missing Unique ID:", uids_missing)

# ---- Sample card sanity check ----
if cards:
    sample = cards[0].copy()
    sample["_citations"] = sample.get("_citations", [])[:3]
    print("\nSample card:")
    for k in ["Unique ID", "Activity Name", "Submitting ICO", "Lead ICO", "_citations"]:
        print(f" - {k}: {sample.get(k)}")


# COMMAND ----------

# MAGIC %md
# MAGIC Style prompt loading & validation

# COMMAND ----------

# Cell 4 — Load and validate style_prompt.json (NO LLM calls)

from pathlib import Path
import json

def load_style_prompt(path: str) -> str:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"style_prompt.json not found at: {path}")

    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in style_prompt.json: {e}")

    if "content" not in obj:
        raise KeyError("style_prompt.json must contain a top-level 'content' key")

    content = obj["content"]

    if isinstance(content, list):
        if not all(isinstance(x, str) for x in content):
            raise TypeError("'content' list must contain only strings")
        text = "\n".join(content)
    elif isinstance(content, str):
        text = content
    else:
        raise TypeError("'content' must be either a string or a list of strings")

    if len(text.strip()) < 50:
        raise ValueError("style_prompt content looks too short to be valid")

    return text.strip()

SYSTEM_TEXT = load_style_prompt(STYLE_PROMPT)

print("✅ style_prompt.json loaded successfully")
print("SYSTEM_TEXT length (chars):", len(SYSTEM_TEXT))
print("\n--- SYSTEM_TEXT (first 500 chars) ---\n")
print(SYSTEM_TEXT[:500])


# COMMAND ----------

# MAGIC %md
# MAGIC Single LLM call for ONE UID, safe test

# COMMAND ----------

# Cell 5 — Single controlled LLM call (ONE UID only, SELF-CONTAINED)

import json, re, time, requests

# --- Explicit generation knobs (do NOT rely on earlier cells) ---
TEMPERATURE = 0.25
MAX_TOKENS = 550

# --- Use the system prompt you loaded ---
SYSTEM_CUE = SYSTEM_TEXT

# --- FMAPI caller ---
def call_fmapi(messages, max_tokens=MAX_TOKENS, temperature=TEMPERATURE, retries=2):
    url = f"{HOST}/serving-endpoints/{ENDPOINT}/invocations"
    headers = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
    payload = {
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature
    }

    last_err = None
    for attempt in range(retries + 1):
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=60)
            if r.status_code == 401:
                raise RuntimeError(
                    "401 Unauthorized from invocations. "
                    "Check endpoint permissions for this notebook identity."
                )
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_err = e
            time.sleep(0.6)
    raise last_err

# --- Cleaner ---
_FENCE = re.compile(r"```(?:json|md)?\s*|```", re.I)
_URL = re.compile(r'https?://\S+')
_ODD_SUP = re.compile(r'[\u2070-\u209F\u02B0-\u02FF]')

def extract_text(d) -> str:
    msg = None
    try:
        msg = d["choices"][0]["message"]["content"]
    except Exception:
        pass

    if isinstance(msg, list):
        parts = []
        for chunk in msg:
            if isinstance(chunk, dict) and chunk.get("type") == "reasoning":
                continue
            if isinstance(chunk, dict) and chunk.get("type") == "text":
                parts.append(chunk.get("text", ""))
        txt = "\n".join(parts)
    elif isinstance(msg, str):
        txt = msg
    else:
        txt = json.dumps(d, indent=2)

    txt = _FENCE.sub("", txt)
    txt = _URL.sub("", txt)
    txt = _ODD_SUP.sub("", txt)
    txt = re.sub(r"[ \t]+\n", "\n", txt)
    return txt.strip()

# --- Row facts ---
def row_facts(card: dict) -> dict:
    return {
        "Submitting ICO": card.get("Submitting ICO","—"),
        "Lead ICO": card.get("Lead ICO","—"),
        "Collaborating ICOs/Agencies/Orgs": card.get("Collaborating ICOs/Agencies/Orgs","—"),
        "Activity Name": card.get("Activity Name","—"),
        "Activity Description": card.get("Activity Description","—"),
        "Unique ID": card.get("Unique ID","—"),
    }

ROW_INSTR = (
    "- Using ONLY these fields, write a 3–5 sentence paragraph in NIH house style.\n"
    "- Include: Submitting ICO, Lead ICO, Collaborators, Activity Name, and the essence of Activity Description.\n"
    "- Do NOT include Activity Type or Importance explicitly.\n"
    "- Do NOT include any URLs, PMIDs, tables, lists, JSON, code fences, or metadata. Output pure prose only.\n"
    "- Append a single UID superscript marker for this row at the VERY END of the paragraph, formatted as [^<UID>].\n"
)

# --- Select one UID deterministically ---
test_uid = sorted(uid_index.keys())[0]
card = uid_index[test_uid]
facts = row_facts(card)

print("✅ Testing UID:", test_uid)
print("Activity Name:", facts.get("Activity Name"))

user_msg = {
    "role": "user",
    "content": ROW_INSTR + "\n" + json.dumps(facts, ensure_ascii=False)
}

resp = call_fmapi(
    messages=[
        {"role": "system", "content": SYSTEM_CUE},
        user_msg
    ],
    max_tokens=MAX_TOKENS,
    temperature=TEMPERATURE
)

txt = extract_text(resp).strip()
txt = re.sub(r"\s+", " ", txt).strip()

# Enforce UID marker
if not re.search(rf"\[\^\s*{re.escape(test_uid)}\s*\]\s*$", txt):
    txt = txt.rstrip(" .") + f". [^{test_uid}]"

print("\n--- Generated paragraph ---\n")
print(txt)

# --- Compliance checks ---
has_url = bool(re.search(r"https?://", txt))
has_pmid_word = "pmid" in txt.lower()
has_list = bool(re.search(r"(^|\s)(- |\* )", txt))
has_uid_end = bool(re.search(rf"\[\^\s*{re.escape(test_uid)}\s*\]\s*$", txt))
sentence_count = len(re.findall(r"[.!?]+", txt))

print("\n--- Compliance checks ---")
print("UID marker at end:", has_uid_end)
print("Contains URL (must be False):", has_url)
print("Contains 'PMID' (must be False):", has_pmid_word)
print("Looks like a bullet list (must be False):", has_list)
print("Sentence count:", sentence_count)


# COMMAND ----------

# MAGIC %md
# MAGIC Fix function: ensure_single_uid_marker(txt, uid)

# COMMAND ----------

# Cell 6 — Enforce exactly ONE UID marker at end (fix duplication)

import re

def ensure_single_uid_marker(text: str, uid: str) -> str:
    """
    Ensures exactly one [^<uid>] marker at the very end of the paragraph.
    Removes duplicates and normalizes punctuation/spacing.
    """
    t = (text or "").strip()

    # Remove any number of trailing UID markers (with optional punctuation/spaces)
    # Examples it cleans:
    #   "... [^UID]"
    #   "... [^UID]."
    #   "... [^UID]. [^UID]"
    #   "... [^UID] [^UID]"
    t = re.sub(rf"(?:\s*\[\^\s*{re.escape(uid)}\s*\]\s*\.?\s*)+$", "", t).strip()

    # Ensure terminal punctuation before marker
    if not re.search(r"[.!?]$", t):
        t = t.rstrip(" .") + "."

    # Append exactly one marker
    return f"{t} [^{uid}]"

# --- Re-test with the last paragraph you generated (paste if variable not present) ---
# If you still have `txt` in memory from Cell 5, this will work directly.
try:
    _raw = txt
except NameError:
    raise NameError("Variable `txt` not found. Please run Cell 5 again to regenerate `txt`, then run this cell.")

fixed = ensure_single_uid_marker(_raw, test_uid)

print("\n--- BEFORE ---\n")
print(_raw)

print("\n--- AFTER (fixed) ---\n")
print(fixed)

# Quick validation
end_ok = bool(re.search(rf"\[\^\s*{re.escape(test_uid)}\s*\]\s*$", fixed))
dup_ok = len(re.findall(rf"\[\^\s*{re.escape(test_uid)}\s*\]", fixed)) == 1

print("\n--- Checks ---")
print("Marker at end:", end_ok)
print("Exactly one marker in paragraph:", dup_ok)


# COMMAND ----------

# MAGIC %md
# MAGIC Generate row paragraphs for ALL 14 UIDs, with progress + safe fallbacks

# COMMAND ----------

# Cell 7 — Generate row paragraphs for all filtered UIDs (14 rows)

import json, re, time, requests

# ---- Generation knobs (explicit, do not rely on earlier cells) ----
TEMPERATURE = 0.25
MAX_TOKENS_ROW = 550

SYSTEM_CUE = SYSTEM_TEXT

# ---- FMAPI caller ----
def call_fmapi(messages, max_tokens=MAX_TOKENS_ROW, temperature=TEMPERATURE, retries=2):
    url = f"{HOST}/serving-endpoints/{ENDPOINT}/invocations"
    headers = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
    payload = {"messages": messages, "max_tokens": max_tokens, "temperature": temperature}

    last_err = None
    for attempt in range(retries + 1):
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=60)
            if r.status_code == 401:
                raise RuntimeError("401 Unauthorized from invocations.")
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_err = e
            time.sleep(0.6)
    raise last_err

# ---- Cleaner ----
_FENCE = re.compile(r"```(?:json|md)?\s*|```", re.I)
_URL = re.compile(r'https?://\S+')
_ODD_SUP = re.compile(r'[\u2070-\u209F\u02B0-\u02FF]')

def extract_text(d) -> str:
    msg = None
    try:
        msg = d["choices"][0]["message"]["content"]
    except Exception:
        pass

    if isinstance(msg, list):
        parts = []
        for chunk in msg:
            if isinstance(chunk, dict) and chunk.get("type") == "reasoning":
                continue
            if isinstance(chunk, dict) and chunk.get("type") == "text":
                parts.append(chunk.get("text", ""))
        txt = "\n".join(parts)
    elif isinstance(msg, str):
        txt = msg
    else:
        txt = json.dumps(d, indent=2)

    txt = _FENCE.sub("", txt)
    txt = _URL.sub("", txt)
    txt = _ODD_SUP.sub("", txt)
    txt = re.sub(r"[ \t]+\n", "\n", txt)
    return txt.strip()

# ---- Marker enforcement (from Cell 6) ----
def ensure_single_uid_marker(text: str, uid: str) -> str:
    t = (text or "").strip()
    t = re.sub(rf"(?:\s*\[\^\s*{re.escape(uid)}\s*\]\s*\.?\s*)+$", "", t).strip()
    if not re.search(r"[.!?]$", t):
        t = t.rstrip(" .") + "."
    return f"{t} [^{uid}]"

# ---- Row facts ----
def row_facts(card: dict) -> dict:
    return {
        "Submitting ICO": card.get("Submitting ICO","—"),
        "Lead ICO": card.get("Lead ICO","—"),
        "Collaborating ICOs/Agencies/Orgs": card.get("Collaborating ICOs/Agencies/Orgs","—"),
        "Activity Name": card.get("Activity Name","—"),
        "Activity Description": card.get("Activity Description","—"),
        "Unique ID": card.get("Unique ID","—"),
    }

ROW_INSTR = (
    "- Using ONLY these fields, write a 3–5 sentence paragraph in NIH house style.\n"
    "- Include: Submitting ICO, Lead ICO, Collaborators, Activity Name, and the essence of Activity Description.\n"
    "- Do NOT include Activity Type or Importance explicitly.\n"
    "- Do NOT include any URLs, PMIDs, tables, lists, JSON, code fences, or metadata. Output pure prose only.\n"
    "- Append a single UID superscript marker for this row at the VERY END of the paragraph, formatted as [^<UID>].\n"
)

# ---- Generate for all UIDs ----
uids = sorted(uid_index.keys())
uid_to_paragraph = {}
failed = []

print(f"Starting row paragraph generation for {len(uids)} UIDs...")

for i, uid in enumerate(uids, 1):
    card = uid_index[uid]
    facts = row_facts(card)

    user_msg = {"role": "user", "content": ROW_INSTR + "\n" + json.dumps(facts, ensure_ascii=False)}

    try:
        resp = call_fmapi(
            messages=[{"role": "system", "content": SYSTEM_CUE}, user_msg],
            max_tokens=MAX_TOKENS_ROW,
            temperature=TEMPERATURE
        )
        raw = extract_text(resp)
        raw = re.sub(r"\s+", " ", raw).strip()
        fixed = ensure_single_uid_marker(raw, uid)

        uid_to_paragraph[uid] = fixed
        print(f"[{i:02d}/{len(uids)}] ✅ {uid}")
    except Exception as e:
        failed.append((uid, str(e)))
        print(f"[{i:02d}/{len(uids)}] ❌ {uid} -> {e}")

print("\n✅ Done.")
print("Generated paragraphs:", len(uid_to_paragraph))
print("Failures:", len(failed))

if failed:
    print("\n--- Failures (uid, error) ---")
    for uid, err in failed:
        print(uid, "->", err)

# Show 2 samples
print("\n--- Sample paragraphs (2) ---")
for uid in uids[:2]:
    if uid in uid_to_paragraph:
        print("\n", uid, "\n", uid_to_paragraph[uid])


# COMMAND ----------

# MAGIC %md
# MAGIC Section routing for the filtered subset, no LLM

# COMMAND ----------

# Cell 8 — Section routing for the filtered subset (NO LLM calls)

# SECTION_ORDER from your baseline
SECTION_ORDER = [
    "Advanced Imaging & AI Tools",
    "Combination & Targeted Therapies",
    "Data Commons and Computational Resources",
    "Environmental Health and Cancer",
    "Epidemiology & Surveillance",
    "Genetics, Cell Biology, and -Omics",
    "Immunotherapy",
    "Nutrition & Symptom Management",
    "Preventive Interventions",
    "Recalcitrant & Hard-to-Treat Cancer Research",
    "Screening & Early Detection",
    "Tumor Microenvironment & Immunology",
]

SECTIONS = ["Introduction"] + SECTION_ORDER

def pick_sections(card: dict) -> list:
    """Return one or more sections for the row."""
    text = " ".join([
        card.get("Activity Name",""),
        card.get("Activity Description",""),
        card.get("Activity Type",""),
        card.get("Importance",""),
        card.get("Collaborating ICOs/Agencies/Orgs",""),
    ]).lower()

    hits = set()

    def has_any(keys):
        return any(k in text for k in keys)

    # Introduction (cross-cutting)
    if has_any([
        "overview","cross-cutting","crosscutting","portfolio","program-wide","programwide",
        "initiative","roadmap","framework","guideline","strategy","strategic plan","coordination",
        "coordinating center","coordination center","steering committee","consortium","network",
        "multi-site","multisite","collaborative","collaboration","partnership","interagency",
        "infrastructure","platform","shared resource","core facility","service core","resource hub",
        "repository","biorepository","biobank","registry","data sharing","fa ir","fair principles",
        "standard","standards","standardization","harmonization","interoperab","governance","policy",
        "cloud","workspace","portal","catalog","metadata","provenance",
        "implementation","implementation science","real-world","real world","pragmatic",
        "learning health system","lhs","scale-up","scale up","uptake","adoption","dissemination",
        "fidelity","reach","sustainment","cost-effectiveness","cost effectiveness",
        "equity","equitable","disparity","disparities","underserved","under-served","rural",
        "access","barrier","barriers","inequity","minority","safety-net","safety net",
        "workforce","training","education","educational","curriculum","mentoring","mentor","mentorship",
        "career development","pipeline","capacity building","workshop","bootcamp","short course",
        "survivorship","quality of life","qol","rehabilitation","supportive care",
        "mission","vision","objectives","objectives include","goal is to","goals include"
    ]):
        hits.add("Introduction")

    # Thematic routing
    if has_any(["image","imaging","radiology","ai","ml","deep learning","pet","mri","ct","midrc"]):
        hits.add("Advanced Imaging & AI Tools")
    if has_any(["combination","combo","targeted","inhibitor","kinase","precision","molecularly targeted","combo therapy"]):
        hits.add("Combination & Targeted Therapies")
    if has_any(["commons","repository","portal","database","computational","cloud","workflow","data hub","registry"]):
        hits.add("Data Commons and Computational Resources")
    if has_any(["environmental","exposure","toxic","pollut","air","water","environment","occupational"]):
        hits.add("Environmental Health and Cancer")
    if has_any(["epidemiology","surveillance","registry","incidence","prevalence","cohort","population"]):
        hits.add("Epidemiology & Surveillance")
    if has_any(["genetic","genome","omics","transcript","proteomic","epigen","cell","mechanism","mutation","gene"]):
        hits.add("Genetics, Cell Biology, and -Omics")
    if has_any(["immunotherapy","checkpoint","t cell","car-t","immune","nk cell","neoantigen"]):
        hits.add("Immunotherapy")
    if has_any(["nutrition","diet","exercise","symptom","quality of life","palliative","cachexia"]):
        hits.add("Nutrition & Symptom Management")
    if has_any(["prevent","screen","risk reduction","vaccin","hpv","self-collection"]):
        hits.add("Preventive Interventions")
    if has_any(["recalcitrant","hard-to-treat","glioblastoma","pancreatic","rare","refractory"]):
        hits.add("Recalcitrant & Hard-to-Treat Cancer Research")
    if has_any(["screen","early detection","biomarker","liquid biopsy","mcde"]):
        hits.add("Screening & Early Detection")
    if has_any(["microenvironment","stroma","stromal","macrophage","myeloid","tme","caf"]):
        hits.add("Tumor Microenvironment & Immunology")

    # Fallback
    if not hits:
        hits.add("Genetics, Cell Biology, and -Omics")

    # Sort: keep Introduction first if present, then in SECTION_ORDER order
    ordered = []
    if "Introduction" in hits:
        ordered.append("Introduction")
    ordered += [s for s in SECTION_ORDER if s in hits]
    return ordered

# Build map: section -> uids
section_to_uids = {s: [] for s in SECTIONS}

for c in cards:
    uid = c.get("Unique ID", "—")
    if not uid or uid == "—":
        continue
    for sec in pick_sections(c):
        section_to_uids[sec].append(uid)

# Print summary (only sections with content)
print("✅ Section routing summary (only populated sections):")
for sec in ["Introduction"] + SECTION_ORDER:
    uids = section_to_uids.get(sec, [])
    if uids:
        print(f"- {sec}: {len(uids)} UID(s)")

# Optional: show the actual UID lists for populated sections
print("\n--- UID lists by section ---")
for sec in ["Introduction"] + SECTION_ORDER:
    uids = section_to_uids.get(sec, [])
    if uids:
        print(f"\n{sec}:")
        print(", ".join(uids))


# COMMAND ----------

# MAGIC %md
# MAGIC Set corrected intro constraints + define fiscal year extraction

# COMMAND ----------

# Cell 9 — Normalize Introduction constraints (NO LLM calls)

import re

# ---- Corrected Introduction constraints (consistent with your prompt) ----
INTRO_MIN_PARAS   = 9
INTRO_TARGET_MAX  = 13
INTRO_MIN_WORDS   = 120         # FIX: was 400; now matches 120–180 guidance
INTRO_RETRY_LIMIT = 6           # reduce retries to control cost; can increase later

print("✅ Introduction constraints set:")
print(" - INTRO_MIN_PARAS:", INTRO_MIN_PARAS)
print(" - INTRO_TARGET_MAX:", INTRO_TARGET_MAX)
print(" - INTRO_MIN_WORDS:", INTRO_MIN_WORDS)
print(" - INTRO_RETRY_LIMIT:", INTRO_RETRY_LIMIT)

# ---- Fiscal year extraction (from the FILTERED dataset, not the full dataset) ----
def detect_fiscal_years(filtered_df):
    fy_candidates = [
        c for c in filtered_df.columns
        if str(c).lower().strip() in ("fiscal year","fiscal_year","fy","year")
    ]
    if not fy_candidates:
        return []
    fy_col = fy_candidates[0]
    years = [
        str(v).strip() for v in filtered_df[fy_col].tolist()
        if str(v).strip() not in ("—", "", "nan", "None")
    ]
    return sorted(set(years))

fiscal_years = detect_fiscal_years(filtered)
print("\n✅ fiscal_years detected:", fiscal_years if fiscal_years else "(none found)")

# ---- Helper functions used later by intro generator ----
def _count_words(txt: str) -> int:
    return len([w for w in re.findall(r"\b\w+\b", txt)])

def _split_paragraphs(md: str):
    return [p.strip() for p in re.split(r"\n\s*\n", md) if p.strip()]

def _intro_meets_shape(md: str, min_paras: int, min_words: int, target_max: int) -> bool:
    paras = _split_paragraphs(md)
    if len(paras) < min_paras:
        return False
    if len(paras) > target_max:
        # We tolerate slight overflow, but treat this as failing so we can tighten.
        return False
    for p in paras:
        if _count_words(p) < min_words:
            return False
    return True

print("\n✅ Intro helper functions ready.")


# COMMAND ----------

# MAGIC %md
# MAGIC Generate Introduction only, controlled, with retries

# COMMAND ----------

# Cell 10 — Generate Introduction (LLM calls; controlled shape)

import json, re, time, requests, collections

# ---- Explicit generation knobs for intro ----
TEMPERATURE = 0.25
MAX_TOKENS_INTRO = 3600

SYSTEM_CUE = SYSTEM_TEXT

def call_fmapi(messages, max_tokens=MAX_TOKENS_INTRO, temperature=TEMPERATURE, retries=2):
    url = f"{HOST}/serving-endpoints/{ENDPOINT}/invocations"
    headers = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
    payload = {"messages": messages, "max_tokens": max_tokens, "temperature": temperature}

    last_err = None
    for attempt in range(retries + 1):
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=90)
            if r.status_code == 401:
                raise RuntimeError("401 Unauthorized from invocations.")
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_err = e
            time.sleep(0.6)
    raise last_err

# ---- Reuse cleaner ----
_FENCE = re.compile(r"```(?:json|md)?\s*|```", re.I)
_URL = re.compile(r"https?://\S+")
_ODD_SUP = re.compile(r"[\u2070-\u209F\u02B0-\u02FF]")

def extract_text(d) -> str:
    msg = None
    try:
        msg = d["choices"][0]["message"]["content"]
    except Exception:
        pass

    if isinstance(msg, list):
        parts = []
        for chunk in msg:
            if isinstance(chunk, dict) and chunk.get("type") == "reasoning":
                continue
            if isinstance(chunk, dict) and chunk.get("type") == "text":
                parts.append(chunk.get("text", ""))
        txt = "\n".join(parts)
    elif isinstance(msg, str):
        txt = msg
    else:
        txt = json.dumps(d, indent=2)

    txt = _FENCE.sub("", txt)
    txt = _URL.sub("", txt)
    txt = _ODD_SUP.sub("", txt)
    txt = re.sub(r"[ \t]+\n", "\n", txt)
    return txt.strip()

# ---- Build truthful intro payload from current filtered subset ----
def top_participating_ics(cards, k=8):
    counter = collections.Counter()
    for c in cards:
        for key in ("Submitting ICO", "Lead ICO"):
            val = (c.get(key) or "—").strip()
            if val and val != "—":
                counter[val] += 1
    return [name for name, _ in counter.most_common(k)]

field_value = selected_field
activity_type_value = selected_activity_type

payload = {
    "meta": {
        "field_filter": field_value,
        "activity_type_filter": activity_type_value,
        "fiscal_years": fiscal_years or []
    },
    "counts": {
        "rows": len(cards),
        "unique_uids": len(uid_index)
    },
    "institutes_top": top_participating_ics(cards, k=8),
    "allowed_uids": sorted(uid_index.keys())  # critical: forbid inventing UIDs
}

INTRO_INSTR = (
    f"- Write {INTRO_MIN_PARAS} to {INTRO_TARGET_MAX} long, substantive paragraphs for the Introduction of an NIH Triennial report.\n"
    "- Use only the facts in the provided payload (meta, counts, top institutes, and allowed_uids).\n"
    "- Do not invent fiscal years; if fiscal_years is empty, do not mention an FY range.\n"
    "- Discuss scientific aims, collaboration patterns, infrastructure/resources, equity/access considerations, translational impact, and implementation context.\n"
    "- Include at least four UID markers overall to anchor claims, formatted as [^<UID>].\n"
    "- You may only use UID markers from allowed_uids; do not create new UIDs.\n"
    "- No bullets; output clean multi-paragraph Markdown prose.\n"
    "- No URLs/PMIDs/JSON/metadata; output pure prose paragraphs only.\n"
    f"- Each paragraph must be at least {INTRO_MIN_WORDS} words.\n"
)

def sanitize_intro(md: str) -> str:
    # Remove headings if model inserts them
    md = re.sub(r"^\s{0,3}#{1,6}\s+.*$", "", md, flags=re.MULTILINE)
    md = re.sub(r"\n{2,}", "\n\n", md)
    md = re.sub(r"[ \t]+\n", "\n", md)
    return md.strip()

def intro_revision_message(current_text: str) -> str:
    return (
        "REVISION REQUEST:\n"
        f"- Must contain between {INTRO_MIN_PARAS} and {INTRO_TARGET_MAX} paragraphs.\n"
        f"- Each paragraph must be at least {INTRO_MIN_WORDS} words.\n"
        "- Include at least four UID markers total, using ONLY allowed_uids.\n"
        "- Do not add headings or bullet points.\n"
        "- Output only the revised multi-paragraph text.\n\n"
        "CURRENT TEXT:\n"
        f"{current_text}\n"
    )

# ---- Generate + retry until shape passes ----
content = INTRO_INSTR + "\n" + json.dumps(payload, ensure_ascii=False)

resp = call_fmapi(
    messages=[{"role": "system", "content": SYSTEM_CUE},
              {"role": "user", "content": content}],
    max_tokens=MAX_TOKENS_INTRO,
    temperature=TEMPERATURE
)

INTRO_TEXT = sanitize_intro(extract_text(resp))

attempts = 0
while not _intro_meets_shape(INTRO_TEXT, INTRO_MIN_PARAS, INTRO_MIN_WORDS, INTRO_TARGET_MAX) and attempts < INTRO_RETRY_LIMIT:
    attempts += 1
    revision = intro_revision_message(INTRO_TEXT)
    resp2 = call_fmapi(
        messages=[
            {"role": "system", "content": SYSTEM_CUE},
            {"role": "user", "content": content},
            {"role": "user", "content": revision}
        ],
        max_tokens=MAX_TOKENS_INTRO,
        temperature=TEMPERATURE
    )
    candidate = sanitize_intro(extract_text(resp2))
    if _intro_meets_shape(candidate, INTRO_MIN_PARAS, INTRO_MIN_WORDS, INTRO_TARGET_MAX):
        INTRO_TEXT = candidate
        break
    INTRO_TEXT = candidate

# ---- Print shape diagnostics ----
paras = _split_paragraphs(INTRO_TEXT)
uid_marks = re.findall(r"\[\^\s*([A-Za-z0-9._-]+)\s*\]", INTRO_TEXT)

print("✅ Introduction generated.")
print("Paragraph count:", len(paras))
print("Min words per paragraph:", min(_count_words(p) for p in paras) if paras else 0)
print("Total UID markers:", len(uid_marks))
print("Unique UID markers:", len(set(uid_marks)))
print("Attempts used:", attempts)

# Show first 2 paragraphs only (avoid flooding output)
print("\n--- Intro preview (first 2 paragraphs) ---\n")
print(paras[0])
print("\n")
print(paras[1] if len(paras) > 1 else "")


# COMMAND ----------

# MAGIC %md
# MAGIC Generate Section-Level Syntheses (Pilot Sections)

# COMMAND ----------

# Helper — clean and normalize UID usage in section syntheses

def normalize_synthesis_uids(text: str, allowed_uids: list[str]) -> str:
    """
    - Remove plain-text mentions like 'activity 109_NIAMS'
    - Ensure at most one UID marker [^UID] appears
    - If no marker exists, append one allowed UID at the end
    """
    txt = text or ""

    # Remove 'activity XYZ' style mentions
    for uid in allowed_uids:
        txt = re.sub(rf"\bactivity\s+{re.escape(uid)}\b", "", txt, flags=re.I)

    # Detect existing UID markers
    markers = re.findall(r"\[\^\s*([A-Za-z0-9._-]+)\s*\]", txt)
    markers = [m for m in markers if m in allowed_uids]

    # Remove all existing markers (we will re-add at most one)
    txt = re.sub(r"\[\^\s*[A-Za-z0-9._-]+\s*\]", "", txt).strip()

    # Append one marker if possible
    if allowed_uids:
        uid = markers[0] if markers else allowed_uids[0]
        if not txt.endswith("."):
            txt += "."
        txt += f" [^{uid}]"

    return re.sub(r"\s+", " ", txt).strip()


# COMMAND ----------

# Cell 11 — Section synthesis (2 sections only, controlled)

import json, re, time, requests

# ---- Explicit knobs ----
TEMPERATURE = 0.25
MAX_TOKENS_SYN = 450
SYSTEM_CUE = SYSTEM_TEXT

# ---- FMAPI caller (reuse pattern) ----
def call_fmapi(messages, max_tokens=MAX_TOKENS_SYN, temperature=TEMPERATURE, retries=2):
    url = f"{HOST}/serving-endpoints/{ENDPOINT}/invocations"
    headers = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
    payload = {"messages": messages, "max_tokens": max_tokens, "temperature": temperature}

    last_err = None
    for _ in range(retries + 1):
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=60)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_err = e
            time.sleep(0.6)
    raise last_err

# ---- Cleaner ----
_FENCE = re.compile(r"```(?:json|md)?\s*|```", re.I)

def extract_text(d) -> str:
    try:
        txt = d["choices"][0]["message"]["content"]
    except Exception:
        return ""

    if isinstance(txt, list):
        txt = "\n".join(
            c["text"] for c in txt
            if isinstance(c, dict) and c.get("type") == "text"
        )

    txt = _FENCE.sub("", txt)
    txt = re.sub(r"\s+", " ", txt)
    return txt.strip()

# ---- Synthesis instruction ----
SYNTH_INSTR = (
    "- Write one or two cohesive synthesis paragraphs for the section title below.\n"
    "- Use ONLY the provided row facts.\n"
    "- Focus on scientific themes, methods, and collaboration patterns.\n"
    "- Do NOT repeat individual activity descriptions verbatim.\n"
    "- Do NOT mention Activity Type or Importance labels.\n"
    "- Optionally include ONE UID marker at the end if a concrete example strengthens the synthesis.\n"
    "- No bullets, no headings, no URLs, no metadata.\n"
)

def section_synthesis(section_name, uids):
    rows = []
    for u in uids[:6]:  # cap to avoid token bloat
        c = uid_index[u]
        rows.append({
            "UID": u,
            "Submitting ICO": c.get("Submitting ICO","—"),
            "Lead ICO": c.get("Lead ICO","—"),
            "Activity Name": c.get("Activity Name","—"),
            "Activity Description": (c.get("Activity Description","—")[:400])
        })

    payload = {"section": section_name, "rows": rows}

    resp = call_fmapi(
        messages=[
            {"role": "system", "content": SYSTEM_CUE},
            {"role": "user", "content": SYNTH_INSTR + "\n" + json.dumps(payload, ensure_ascii=False)}
        ]
    )

    txt = extract_text(resp)

    # Remove any accidental headings
    txt = re.sub(r"^\s{0,3}#{1,6}\s+.*$", "", txt, flags=re.MULTILINE)
    txt = txt.strip()

    return txt

# ---- Target sections ----
TARGET_SECTIONS = [
    "Advanced Imaging & AI Tools",
    "Genetics, Cell Biology, and -Omics"
]

SECTION_SYN = {}

for sec in TARGET_SECTIONS:
    uids = section_to_uids.get(sec, [])
    if not uids:
        continue
    print(f"Generating synthesis for: {sec} ({len(uids)} UIDs)")
    #SECTION_SYN[sec] = section_synthesis(sec, uids)
    raw_syn = section_synthesis(sec, uids)
    SECTION_SYN[sec] = normalize_synthesis_uids(raw_syn, uids)
    print("OK\n")

# ---- Show results ----
for sec in TARGET_SECTIONS:
    if sec in SECTION_SYN:
        print("\n---", sec, "---\n")
        print(SECTION_SYN[sec])

# COMMAND ----------

# MAGIC %md
# MAGIC Generate syntheses for all remaining populated sections

# COMMAND ----------

# Cell 12 — Generate syntheses for all remaining sections (normalized)

SECTION_SYN = {}  # reset to include all sections

for sec in SECTION_ORDER:
    uids = section_to_uids.get(sec, [])
    if not uids:
        continue

    print(f"Generating synthesis for: {sec} ({len(uids)} UIDs)")
    raw_syn = section_synthesis(sec, uids)
    SECTION_SYN[sec] = normalize_synthesis_uids(raw_syn, uids)
    print("OK\n")

# ---- Summary ----
print("✅ Syntheses generated for sections:")
for sec in SECTION_SYN:
    print("-", sec)

# COMMAND ----------

# MAGIC %md
# MAGIC Assemble Final Step-6 Markdown (Deterministic, No LLM)

# COMMAND ----------

# Cell 13 — Assemble final Step-6 Markdown (deterministic)

import re

md_parts = []

# ------------------------------------------------------------
# 1) Introduction
# ------------------------------------------------------------
assert "INTRO_TEXT" in globals(), "INTRO_TEXT not found. Run Cell 10 first."

md_parts.append("## Introduction\n")
md_parts.append(INTRO_TEXT.strip() + "\n")

# Track which UID paragraphs have already been written
written_uids = set()

# ------------------------------------------------------------
# 2) Thematic Sections
# ------------------------------------------------------------
for sec in SECTION_ORDER:
    uids = section_to_uids.get(sec, [])
    if not uids:
        continue

    md_parts.append(f"\n## {sec}\n")

    # ---- Section synthesis (already normalized) ----
    syn = SECTION_SYN.get(sec, "").strip()
    if syn:
        md_parts.append(syn + "\n")

    # ---- Row-level paragraphs ----
    for uid in uids:
        if uid in written_uids:
            continue
        written_uids.add(uid)

        para = uid_to_paragraph.get(uid, "").strip()
        if not para:
            continue

        # Safety cleanup
        para = re.sub(r"\s+", " ", para).strip()

        # Emit UID heading + paragraph
        md_parts.append(f"\nUID {uid}\n")
        md_parts.append(para + "\n")

# ------------------------------------------------------------
# 3) Final Markdown
# ------------------------------------------------------------
md = "\n".join(md_parts).strip()

# Safety check: exactly one Introduction
intro_count = md.count("\n## Introduction")
if md.startswith("## Introduction"):
    intro_count += 1

assert intro_count == 1, f"❌ Duplicate Introduction detected ({intro_count})"

print("✅ Step-6 Markdown assembled.")
print("Total UID paragraphs:", len(written_uids))
print("Total sections:", len([s for s in SECTION_ORDER if section_to_uids.get(s)]))

# Preview start only
print("\n--- Markdown preview (first 500 chars) ---\n")
print(md[:500])


# COMMAND ----------

# MAGIC %md
# MAGIC Footnote Resolution (Convert UID markers → numeric footnotes + definitions)

# COMMAND ----------

# Cell 14 — Step 7: Convert UID markers to numeric footnotes + append definitions

import re
from pathlib import Path

# --- Patterns ---
_URL_RE = re.compile(r"https?://[^\s),;]+", re.I)
UID_MARK_RE = re.compile(r"\[\^\s*([A-Za-z0-9._-]+)\s*\]")

assert "md" in globals(), "md not found. Run Cell 13 first."

KNOWN_UIDS = set(uid_index.keys())

# --- Keep only UID markers that correspond to real rows ---
def drop_unknown_uid_markers(text: str) -> str:
    return UID_MARK_RE.sub(lambda m: m.group(0) if m.group(1) in KNOWN_UIDS else "", text)

md_clean = drop_unknown_uid_markers(md)

# --- Collect first-appearance order of UIDs in text ---
order, seen = [], set()
for m in UID_MARK_RE.finditer(md_clean):
    u = m.group(1)
    if u in KNOWN_UIDS and u not in seen:
        seen.add(u)
        order.append(u)

# --- Extract valid (non-PubMed) URLs from Excel row ---
def _excel_urls(card: dict) -> list:
    raw = str(card.get("Web address(es)", "") or "")
    parts = re.split(r"[;\n,]\s*", raw)
    urls = []
    for p in parts:
        m = _URL_RE.search(p)
        if m:
            url = m.group(0).strip().rstrip(").,;")
            if "pubmed.ncbi.nlm.nih.gov" not in url.lower():
                urls.append(url)
    # dedupe, preserve order
    out, s = [], set()
    for u in urls:
        if u not in s:
            s.add(u)
            out.append(u)
    return out

# --- Only number UIDs that actually have at least one real web URL ---
uids_with_urls = []
for u in order:
    card = uid_index.get(u)
    if not card:
        continue
    if _excel_urls(card):
        uids_with_urls.append(u)

uid_to_num = {u: i + 1 for i, u in enumerate(uids_with_urls)}

# --- Replace markers:
#     - if UID has a real URL -> [^n]
#     - else -> remove marker entirely
def _marker_repl(m):
    u = m.group(1)
    n = uid_to_num.get(u)
    return f"[^{n}]" if n is not None else ""

md_with_numeric_markers = UID_MARK_RE.sub(_marker_repl, md_clean)

# --- Build Pandoc footnote definitions ---
def _footnote_text(card: dict) -> str:
    orgs = "; ".join(
        [x for x in [card.get("Submitting ICO",""), card.get("Lead ICO","")]
         if x and str(x).strip() and str(x).strip() != "—"]
    )
    title = (card.get("Activity Name","") or "").strip()
    urls = _excel_urls(card)
    parts = [p for p in [orgs, title, "; ".join(urls)] if p]
    return " — ".join(parts).strip()

defs = []
for u in uids_with_urls:
    card = uid_index.get(u)
    if not card:
        continue
    txt = _footnote_text(card)
    n = uid_to_num[u]
    if txt:
        defs.append(f"[^{n}]: {txt}")

# --- Append footnote block ---
if defs:
    md_out = md_with_numeric_markers.rstrip() + "\n\n" + "\n".join(defs) + "\n"
else:
    md_out = md_with_numeric_markers.rstrip() + "\n\n[^1]: No valid external web citations were found.\n"

out_path = Path(f"{OUT_DIR}/report_step7.md")
out_path.write_text(md_out, encoding="utf-8")

print("✅ Step 7 complete.")
print("UIDs encountered in text:", len(order))
print("UIDs with real web URLs:", len(uids_with_urls))
print("Footnote definitions written:", len(defs))
print("📄 Output →", str(out_path))


# COMMAND ----------

# MAGIC %md
# MAGIC Pandoc → DOCX export + Databricks download link

# COMMAND ----------

# Cell 15 — Export DOCX via Pandoc + create download link

from pathlib import Path
import os, subprocess, shlex, shutil

# ---- Inputs ----
md_path = f"{OUT_DIR}/report_step7.md"
assert Path(md_path).exists(), f"Missing markdown file: {md_path}"

# ---- Safe filename ----
def _safe(s: str) -> str:
    s = (s or "output").strip()
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_")[:80] or "output"

field_part = _safe(selected_field if "selected_field" in globals() else FIELD_FILTER)
atype_part = _safe(selected_activity_type if "selected_activity_type" in globals() else "All")
docx_path = f"{OUT_DIR}/Triennial_Data_{field_part}_{atype_part}.docx"

# ---- Pandoc install (idempotent) ----
PANDOC = "/databricks/driver/bin/pandoc"
if not Path(PANDOC).exists():
    print("Pandoc not found, installing...")
    # install pandoc binary under /databricks/driver/bin
    install_sh = r"""
set -euo pipefail
PVER="3.3"
WORKDIR="/databricks/driver"
cd "$WORKDIR"
curl -L -o pandoc.tgz "https://github.com/jgm/pandoc/releases/download/${PVER}/pandoc-${PVER}-linux-amd64.tar.gz"
tar -xzf pandoc.tgz
mkdir -p "$WORKDIR/bin"
cp "pandoc-${PVER}/bin/pandoc" "$WORKDIR/bin/pandoc"
chmod +x "$WORKDIR/bin/pandoc"
echo "Installed:"
/databricks/driver/bin/pandoc -v | head -n 2
"""
    subprocess.run(["bash", "-lc", install_sh], check=True)
else:
    print("✅ Pandoc already installed:", PANDOC)

assert Path(PANDOC).exists(), f"Pandoc not found: {PANDOC}"

# ---- Build command ----
env = os.environ.copy()
env["PATH"] = f"/databricks/driver/bin:{env.get('PATH','')}"

cmd = [
    PANDOC,
    md_path,
    "-o", docx_path,
    "--from", "markdown+footnotes+autolink_bare_uris",
    "--to", "docx",
    "--wrap=none",
    "--standalone",
]

# ---- Optional reference doc + Lua filters ----
if "REFERENCE_DOCX" in globals() and Path(REFERENCE_DOCX).exists():
    cmd += ["--reference-doc", REFERENCE_DOCX]

if "LUA_FILTER" in globals() and Path(LUA_FILTER).exists():
    cmd += ["--lua-filter", LUA_FILTER]

# If you created a square-bracket footnote filter earlier, include it if present
SQUARE_FILTER = "/dbfs/FileStore/triennial/h2_square_bracket_footnotes.lua"
if Path(SQUARE_FILTER).exists():
    cmd += ["--lua-filter", SQUARE_FILTER]

print("🧭 Running Pandoc command:")
print(" ".join(shlex.quote(c) for c in cmd))

subprocess.run(cmd, check=True, env=env)
print("✅ DOCX exported successfully →", docx_path)

# ---- Publish download link from FileStore ----
web_dir = "/dbfs/FileStore/triennial/out"
os.makedirs(web_dir, exist_ok=True)

src_path = Path(docx_path)
dst_path = Path(web_dir) / src_path.name

# docx_path is already under FileStore, but keep logic safe
if not str(src_path).startswith("/dbfs/FileStore/"):
    shutil.copy2(src_path, dst_path)
else:
    dst_path = src_path

relative_after_filestore = str(dst_path).replace("/dbfs/FileStore/", "")
download_url = f"/files/{relative_after_filestore}".replace("//", "/")
workspace_url = spark.conf.get("spark.databricks.workspaceUrl", "").rstrip("/")

displayHTML(f"""
  <div style="margin-top:10px;font-size:16px;">
    <a href="https://{workspace_url}{download_url}"
       target="_blank"
       style="font-size:16px; text-decoration:none;">
       <b>Download DOCX: {dst_path.name}</b>
    </a>
  </div>
""")

print("🔗 Download URL:", f"https://{workspace_url}{download_url}")
print("📁 Served from :", str(dst_path))


# COMMAND ----------

# MAGIC %md
# MAGIC Re-print the DOCX download URL (no rebuild, no Pandoc)

# COMMAND ----------

# Cell 16 — Print download URL for the exported DOCX (no rebuild)

from pathlib import Path

docx_path = "/dbfs/FileStore/triennial/out/Triennial_Data_Cancer_Basic_Research.docx"
assert Path(docx_path).exists(), f"Missing DOCX: {docx_path}"

relative_after_filestore = docx_path.replace("/dbfs/FileStore/", "")
download_url = f"/files/{relative_after_filestore}".replace("//", "/")

workspace_url = spark.conf.get("spark.databricks.workspaceUrl", "").rstrip("/")

print("🔗 Download URL:", f"https://{workspace_url}{download_url}")

displayHTML(f"""
  <div style="margin-top:10px;font-size:16px;">
    <a href="https://{workspace_url}{download_url}" target="_blank" style="font-size:16px; text-decoration:none;">
       <b>Download DOCX: {Path(docx_path).name}</b>
    </a>
  </div>
""")
