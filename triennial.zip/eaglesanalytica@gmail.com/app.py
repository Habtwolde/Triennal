# app.py — Databricks Streamlit App: Triennial Report Generator
# APP VERSION: 2025-12-30 v13

import os
import re
import json
import time
import base64
import subprocess
from pathlib import Path
import collectionshttps://adb-4480026081424261.1.azuredatabricks.net/editor/files/1619846748655453?o=4480026081424261$0
import shutil
import requests
from typing import Optional, Tuple

import pandas as pd
import streamlit as st

# Optional DOCX formatting support (python-docx may not exist in Databricks Apps)
DOCX_AVAILABLE = True
try:
    from docx import Document
    from docx.shared import RGBColor
except Exception:
    DOCX_AVAILABLE = False



# =============================
# 0) App config
# =============================
st.set_page_config(page_title="Triennial Report Generator", layout="wide")
st.title("Triennial Report Generator")
st.caption("Select inputs, then filter by Field and Activity Type to generate a publication-ready DOCX report.")
st.write("APP VERSION: 2025-12-30 v13")


# =============================
# UI behavior
# =============================
NARRATE_EVERY_N_DEFAULT = 3
SHOW_PARTIAL_OUTPUT = False
SILENT_STAGING = True


# =============================
# 1) Default paths & constants
# =============================
BASE_DBFS_DEFAULT = "dbfs:/FileStore/triennial"

DEFAULT_EXCEL_DBFS = f"{BASE_DBFS_DEFAULT}/Triennial Data Source_Master File of All Submissions_OEPR Ch3 Writers (1).xlsx"
DEFAULT_STYLE_PROMPT_DBFS = f"{BASE_DBFS_DEFAULT}/style_prompt.json"
DEFAULT_REFERENCE_DOCX_DBFS = f"{BASE_DBFS_DEFAULT}/Triennial Data Source_Style Guide for Triennial Report.docx"

DEFAULT_LUA_FILTER_DBFS = f"{BASE_DBFS_DEFAULT}/h2_pagebreak.lua"
DEFAULT_SQUARE_FILTER_DBFS = f"{BASE_DBFS_DEFAULT}/h2_square_bracket_footnotes.lua"

DEFAULT_WORKING_OUT_DBFS = "dbfs:/FileStore/triennial/out"
DEFAULT_VOLUME_OUT_DIR = "/Volumes/dpcpsi/gold/triennial_reports"

LOCAL_ASSETS_DIR = "/tmp/triennial_assets"
LOCAL_OUT_DIR = "/tmp/triennial_out"
Path(LOCAL_ASSETS_DIR).mkdir(parents=True, exist_ok=True)
Path(LOCAL_OUT_DIR).mkdir(parents=True, exist_ok=True)

EXCEL_LOCAL = str(Path(LOCAL_ASSETS_DIR) / "master.xlsx")
STYLE_PROMPT_LOCAL = str(Path(LOCAL_ASSETS_DIR) / "style_prompt.json")
REFERENCE_DOCX_LOCAL = str(Path(LOCAL_ASSETS_DIR) / "reference.docx")
LUA_FILTER_LOCAL = str(Path(LOCAL_ASSETS_DIR) / "h2_pagebreak.lua")
SQUARE_FILTER_LOCAL = str(Path(LOCAL_ASSETS_DIR) / "h2_square_bracket_footnotes.lua")

ENDPOINT = "databricks-meta-llama-3-3-70b-instruct"

TEMPERATURE = 0.25
MAX_TOKENS_ROW = 550
MAX_TOKENS_SYN = 450
MAX_TOKENS_INTRO = 3000
MAX_TOKENS_SUMMARY = 500

INTRO_MIN_PARAS = 9
INTRO_TARGET_MAX = 13
INTRO_MIN_WORDS = 120
INTRO_RETRY_LIMIT = 6

FIELD_COL = "Field"
ACTIVITY_TYPE_COL = "Activity Type"

CANON = [
    "Submitting ICO", "Lead ICO", "Unique ID", "Collaborating ICOs/Agencies/Orgs",
    "Activity Name", "Activity Description", "Activity Type", "Field", "Importance",
    "Web address(es)", "PMID(s)", "Notes", "Notes.1"
]

SECTION_ORDER = [
    "Advanced Imaging & AI Tools",
    "Combination & Targeted Therapies",
    "Data Commons and Computational Resources",
    "Environmental Health and Cancer",
    "Epidemiology & Surveillance",
    "Genetics, Cell Biology, and -Omics",
    "Immunotherapy",
    "Nutrition & Symptom Management",
    "Preventive Interventions",
    "Recalcitrant & Hard-to-Treat Cancer Research",
    "Screening & Early Detection",
    "Tumor Microenvironment & Immunology",
]


# =============================
# 2) Auth (OAuth from App environment)
# =============================
def _env(name: str) -> str:
    return (os.environ.get(name) or "").strip()


def get_workspace_host() -> str:
    host = _env("DATABRICKS_HOST")
    if host and not host.startswith("http"):
        host = "https://" + host
    return host.rstrip("/")


@st.cache_resource(show_spinner=False)
def get_oauth_token() -> str:
    host = get_workspace_host()
    client_id = _env("DATABRICKS_CLIENT_ID")
    client_secret = _env("DATABRICKS_CLIENT_SECRET")

    if not host or not client_id or not client_secret:
        raise RuntimeError(
            "Missing OAuth env vars inside the App container.\n"
            "Required: DATABRICKS_HOST, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET."
        )

    token_url = f"{host}/oidc/v1/token"
    data = {"grant_type": "client_credentials", "scope": "all-apis"}

    r = requests.post(token_url, data=data, auth=(client_id, client_secret), timeout=30)
    r.raise_for_status()
    return r.json()["access_token"]


def auth_headers() -> dict:
    return {"Authorization": f"Bearer {get_oauth_token()}"}


# =============================
# 3) DBFS REST helpers (Apps-safe)
# =============================
def dbfs_norm(dbfs_path: str) -> str:
    return dbfs_path


def dbfs_get_status(dbfs_path: str) -> dict:
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/get-status"
    r = requests.get(url, headers=auth_headers(), params={"path": dbfs_norm(dbfs_path)}, timeout=30)
    r.raise_for_status()
    return r.json()


def dbfs_read_all(dbfs_path: str, chunk_size: int = 1_000_000) -> bytes:
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/read"
    offset = 0
    out = bytearray()

    while True:
        r = requests.get(
            url,
            headers=auth_headers(),
            params={"path": dbfs_norm(dbfs_path), "offset": offset, "length": chunk_size},
            timeout=60,
        )
        r.raise_for_status()
        j = r.json()

        data_b64 = j.get("data", "") or ""
        data = base64.b64decode(data_b64) if data_b64 else b""
        out.extend(data)

        bytes_read = j.get("bytes_read", 0) or 0
        if bytes_read <= 0:
            break
        offset += bytes_read
        if j.get("eof", False):
            break

    return bytes(out)


def dbfs_write_file(local_path: str, content: bytes):
    p = Path(local_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(content)


def dbfs_mkdirs(dbfs_dir: str):
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/mkdirs"
    r = requests.post(url, headers=auth_headers(), json={"path": dbfs_norm(dbfs_dir)}, timeout=30)
    r.raise_for_status()


def dbfs_delete_if_exists(dbfs_path: str):
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/delete"
    r = requests.post(
        url,
        headers=auth_headers(),
        json={"path": dbfs_norm(dbfs_path), "recursive": False},
        timeout=30,
    )
    if r.status_code not in (200, 404):
        r.raise_for_status()


def dbfs_create(dbfs_path: str, overwrite: bool = True) -> int:
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/create"

    if overwrite:
        dbfs_delete_if_exists(dbfs_path)

    r = requests.post(url, headers=auth_headers(), json={"path": dbfs_norm(dbfs_path)}, timeout=30)
    r.raise_for_status()
    return int(r.json()["handle"])


def dbfs_add_block(handle: int, data_block: bytes):
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/add-block"
    payload = {"handle": handle, "data": base64.b64encode(data_block).decode("utf-8")}
    r = requests.post(url, headers=auth_headers(), json=payload, timeout=60)
    r.raise_for_status()


def dbfs_close(handle: int):
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/close"
    r = requests.post(url, headers=auth_headers(), json={"handle": handle}, timeout=30)
    r.raise_for_status()


def dbfs_put_large(dbfs_path: str, data: bytes, overwrite: bool = True, block_size: int = 1_000_000):
    handle = dbfs_create(dbfs_path, overwrite=overwrite)
    try:
        for i in range(0, len(data), block_size):
            dbfs_add_block(handle, data[i:i + block_size])
    finally:
        dbfs_close(handle)


def stage_assets_or_stop(
    excel_dbfs: str,
    style_prompt_dbfs: str,
    reference_docx_dbfs: str,
    lua_filter_dbfs: Optional[str],
    square_filter_dbfs: Optional[str],
):
    required = [
        (excel_dbfs, EXCEL_LOCAL),
        (style_prompt_dbfs, STYLE_PROMPT_LOCAL),
        (reference_docx_dbfs, REFERENCE_DOCX_LOCAL),
    ]

    optional = []
    if lua_filter_dbfs:
        optional.append((lua_filter_dbfs, LUA_FILTER_LOCAL))
    if square_filter_dbfs:
        optional.append((square_filter_dbfs, SQUARE_FILTER_LOCAL))

    missing_required = []
    for src_dbfs, dst_local in required:
        try:
            _ = dbfs_get_status(src_dbfs)
            data = dbfs_read_all(src_dbfs)
            if not data:
                raise RuntimeError("Empty read")
            dbfs_write_file(dst_local, data)
        except Exception:
            missing_required.append(src_dbfs)

    for src_dbfs, dst_local in optional:
        try:
            _ = dbfs_get_status(src_dbfs)
            data = dbfs_read_all(src_dbfs)
            if data:
                dbfs_write_file(dst_local, data)
        except Exception:
            pass

    if missing_required:
        st.error(
            "The App identity cannot read one or more REQUIRED files from DBFS.\n\n"
            "Missing/unreadable REQUIRED DBFS paths:\n- " + "\n- ".join(missing_required)
        )
        st.stop()

    if not SILENT_STAGING:
        staged = sorted([str(p) for p in Path(LOCAL_ASSETS_DIR).glob("*")])
        st.success("Assets staged into App container (/tmp).")
        st.code("\n".join(staged) or "(no staged files?)")


# =============================
# 4) Utilities
# =============================
def _safe_filename(s: str) -> str:
    s = (s or "output").strip()
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_")[:80] or "output"


def resolve_map(cols):
    lower = {str(c).strip().lower(): str(c).strip() for c in cols}
    m = {}
    for want in CANON:
        w = want.lower()
        if w in lower:
            m[want] = lower[w]
            continue
        found = None
        for k in lower:
            if w.replace(" ", "") in k.replace(" ", ""):
                found = lower[k]
                break
        if found:
            m[want] = found
    return m


def as_str(x):
    if pd.isna(x):
        return "—"
    s = str(x)
    return s if s.strip() else "—"


def split_urls(s):
    if not s or s == "—":
        return []
    out = re.split(r"[;\s,]+", str(s).strip())
    return [p for p in out if p.lower().startswith("http")]


def split_pmids(s):
    if not s or s == "—":
        return []
    return re.findall(r"\b(\d{4,9})\b", str(s))


def _count_words(txt: str) -> int:
    return len([w for w in re.findall(r"\b\w+\b", txt)])


def _split_paragraphs(md: str):
    return [p.strip() for p in re.split(r"\n\s*\n", md) if p.strip()]


def _intro_meets_shape(md: str, min_paras: int, min_words: int, target_max: int) -> bool:
    paras = _split_paragraphs(md)
    if len(paras) < min_paras:
        return False
    if len(paras) > target_max:
        return False
    for p in paras:
        if _count_words(p) < min_words:
            return False
    return True


def build_footnotes_from_uid_markers(md: str, uid_index: dict) -> tuple[str, str]:
    uid_markers = re.findall(r"\[\^([A-Za-z0-9._-]+)\]", md)
    seen = []
    for u in uid_markers:
        if u not in seen:
            seen.append(u)

    uid_to_num = {u: i + 1 for i, u in enumerate(seen)}

    def _repl(m):
        uid = m.group(1)
        n = uid_to_num.get(uid)
        return f"[^{n}]" if n is not None else m.group(0)

    md2 = re.sub(r"\[\^([A-Za-z0-9._-]+)\]", _repl, md)

    defs = []
    for uid in seen:
        card = uid_index.get(uid, {}) or {}
        urls = split_urls(card.get("Web address(es)", ""))
        pmids = split_pmids(card.get("PMID(s)", ""))
        pubmed = [f"https://pubmed.ncbi.nlm.nih.gov/{p}/" for p in pmids]
        extra = card.get("_citations", []) or []

        all_refs = []
        for x in (urls + pubmed + extra):
            x = (x or "").strip()
            if x and x not in all_refs:
                all_refs.append(x)

        if not all_refs:
            all_refs = [f"UID {uid}"]

        n = uid_to_num[uid]
        defs.append(f"[^{n}]: " + "\n    ".join(all_refs))

    footnote_block = "\n\n".join(defs).strip()
    return md2, footnote_block


def parse_hex_color(s: str) -> Optional[Tuple[int, int, int]]:
    """
    Accepts 'blue', '#0000ff', '0000ff', 'rgb(0,0,255)'.
    Returns (r,g,b) or None.
    """
    if not s:
        return None

    t = s.strip().lower()

    # common names
    if t in ("blue", "primary blue"):
        return (0, 0, 255)
    if t in ("red",):
        return (255, 0, 0)
    if t in ("green",):
        return (0, 128, 0)
    if t in ("black",):
        return (0, 0, 0)

    m = re.search(r"rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)", t)
    if m:
        r, g, b = [int(x) for x in m.groups()]
        if all(0 <= x <= 255 for x in (r, g, b)):
            return (r, g, b)

    # hex
    t = t.lstrip("#")
    if re.fullmatch(r"[0-9a-f]{6}", t):
        r = int(t[0:2], 16)
        g = int(t[2:4], 16)
        b = int(t[4:6], 16)
        return (r, g, b)

    return None


def apply_primary_color_to_docx(docx_path: str, rgb: Tuple[int, int, int]) -> None:
    if not DOCX_AVAILABLE:
        # Databricks Apps environment does not include python-docx
        return

    """
    Post-process the generated DOCX to apply a primary font color.
    This is the correct way to make "all text blue" regardless of LLM prompting.

    Notes/limits:
    - Hyperlink color may still follow the Word theme if the Hyperlink style enforces it,
      but we set run color broadly; in most cases this works.
    - Footnotes are included as text runs by Pandoc in the body; if Word stores them
      as actual footnote parts, python-docx has limited access. This still covers most content.
    """
    r, g, b = rgb
    color = RGBColor(r, g, b)

    doc = Document(docx_path)

    # Apply to styles (Normal + headings etc.)
    for style in doc.styles:
        try:
            if hasattr(style, "font") and style.font is not None:
                style.font.color.rgb = color
        except Exception:
            pass

    def _apply_runs_in_paragraph(par):
        for run in par.runs:
            try:
                run.font.color.rgb = color
            except Exception:
                pass

    def _apply_in_table(tbl):
        for row in tbl.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    _apply_runs_in_paragraph(p)
                for nested in cell.tables:
                    _apply_in_table(nested)

    # Main body
    for p in doc.paragraphs:
        _apply_runs_in_paragraph(p)

    for tbl in doc.tables:
        _apply_in_table(tbl)

    # Headers/footers
    for section in doc.sections:
        for p in section.header.paragraphs:
            _apply_runs_in_paragraph(p)
        for p in section.footer.paragraphs:
            _apply_runs_in_paragraph(p)

        for tbl in section.header.tables:
            _apply_in_table(tbl)
        for tbl in section.footer.tables:
            _apply_in_table(tbl)

    doc.save(docx_path)


# =============================
# 5) Load style prompt + Excel (cached)
# =============================
@st.cache_data(show_spinner=False)
def load_system_text(style_prompt_path_local: str) -> str:
    p = Path(style_prompt_path_local)
    if not p.exists():
        raise FileNotFoundError(f"Missing style prompt (local staged): {style_prompt_path_local}")
    sysj = json.loads(p.read_text(encoding="utf-8"))
    content = sysj.get("content", "")
    return "\n".join(content) if isinstance(content, list) else str(content)


@st.cache_data(show_spinner=False)
def load_excel(excel_path_local: str) -> pd.DataFrame:
    p = Path(excel_path_local)
    if not p.exists():
        raise FileNotFoundError(f"Missing Excel (local staged): {excel_path_local}")
    df = pd.read_excel(excel_path_local, sheet_name=0)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def resolve_column(df: pd.DataFrame, col_name: str) -> str:
    if col_name in df.columns:
        return col_name
    lc = {c.lower(): c for c in df.columns}
    return lc.get(col_name.lower(), col_name)


def dropdown_values(df: pd.DataFrame, col: str) -> list[str]:
    vals = df[col].dropna().astype(str).map(str.strip)
    vals = vals[vals != ""]
    return sorted(set(vals.tolist()))


# =============================
# 6) Model Serving call
# =============================
_FENCE = re.compile(r"```(?:json|md)?\s*|```", re.I)
_URL = re.compile(r"https?://\S+")
_ODD_SUP = re.compile(r"[\u2070-\u209F\u02B0-\u02FF]")


def extract_text(d) -> str:
    msg = None
    try:
        msg = d["choices"][0]["message"]["content"]
    except Exception:
        pass

    if isinstance(msg, list):
        parts = []
        for chunk in msg:
            if isinstance(chunk, dict) and chunk.get("type") == "reasoning":
                continue
            if isinstance(chunk, dict) and chunk.get("type") == "text":
                parts.append(chunk.get("text", ""))
        txt = "\n".join(parts)
    elif isinstance(msg, str):
        txt = msg
    else:
        txt = json.dumps(d, indent=2)

    txt = _FENCE.sub("", txt)
    txt = _URL.sub("", txt)
    txt = _ODD_SUP.sub("", txt)
    txt = re.sub(r"[ \t]+\n", "\n", txt)
    return txt.strip()


def call_fmapi(endpoint: str, messages, max_tokens: int, temperature: float, retries: int = 2):
    host = get_workspace_host().rstrip("/")
    candidate_urls = [
        f"{host}/api/2.0/serving-endpoints/{endpoint}/invocations",
        f"{host}/serving-endpoints/{endpoint}/invocations",
    ]

    payload = {"messages": messages, "max_tokens": max_tokens, "temperature": temperature}
    last_err = None

    for attempt in range(retries + 1):
        for url in candidate_urls:
            try:
                headers = {**auth_headers(), "Content-Type": "application/json"}
                r = requests.post(url, headers=headers, json=payload, timeout=180)

                if r.status_code == 401 and attempt == 0:
                    try:
                        get_oauth_token.clear()
                    except Exception:
                        pass
                    headers = {**auth_headers(), "Content-Type": "application/json"}
                    r = requests.post(url, headers=headers, json=payload, timeout=180)

                if r.status_code == 404:
                    continue

                r.raise_for_status()
                return r.json()

            except Exception as e:
                last_err = e

        time.sleep(0.8)

    raise RuntimeError(
        f"Serving invocation failed after retries. Last error: {last_err}. "
        f"Tried URLs: {candidate_urls}"
    )


# =============================
# 6.1) LLM Narrator (REPLACE-IN-PLACE)
# =============================
NARRATOR_MAX_TOKENS = 60
NARRATOR_TEMP = 0.35

NARRATOR_SYSTEM = (
    "You are a concise progress narrator inside a report-generation app.\n"
    "Write exactly ONE short sentence describing what is happening right now.\n"
    "Constraints:\n"
    "- No bullet points, no headings.\n"
    "- No URLs.\n"
    "- No quotes.\n"
    "- No emojis.\n"
    "- Keep it under 18 words.\n"
    "- Businesslike tone.\n"
)


def narrator_line(stage: str, detail: str, context: dict) -> str:
    payload = {
        "stage": stage,
        "detail": detail,
        "field": context.get("field"),
        "activity_type": context.get("activity_type"),
        "counts": context.get("counts", {}),
    }
    messages = [
        {"role": "system", "content": NARRATOR_SYSTEM},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ]
    resp = call_fmapi(
        ENDPOINT,
        messages=messages,
        max_tokens=NARRATOR_MAX_TOKENS,
        temperature=NARRATOR_TEMP,
    )
    txt = extract_text(resp)
    txt = re.sub(r"\s+", " ", txt).strip()
    words = txt.split()
    if len(words) > 18:
        txt = " ".join(words[:18]).rstrip(".") + "."
    if not txt.endswith("."):
        txt += "."
    return txt


# =============================
# 6.2) Preview generator (LLM)
# =============================
PLAN_MAX_TOKENS = 650
PLAN_TEMP = 0.2

PLAN_SYSTEM = (
    "You are a planning assistant for a triennial report generator.\n"
    "Output a short, clear preview in numbered steps.\n"
    "No code. No URLs. No markdown headings.\n"
)


def generate_plan(field_value: str, activity_type_value: str, uid_list: list[str], counts: dict, style_override: str) -> str:
    payload = {
        "field": field_value,
        "activity_type": activity_type_value,
        "counts": counts,
        "uids_preview": uid_list[:30],
        "sections": SECTION_ORDER,
        "style_override": style_override.strip() if style_override else "",
        "pipeline": [
            "Filter rows",
            "Build cards and UID index",
            "Generate row paragraphs (each ends with UID marker)",
            "Route UIDs into sections",
            "Generate Summary",
            "Generate Introduction",
            "Generate section syntheses",
            "Assemble markdown",
            "Convert UID markers to numeric footnotes",
            "Pandoc to DOCX",
            "Optional: apply DOCX primary color override",
            "Publish to DBFS FileStore and offer download",
        ],
    }
    messages = [
        {"role": "system", "content": PLAN_SYSTEM},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ]
    resp = call_fmapi(ENDPOINT, messages=messages, max_tokens=PLAN_MAX_TOKENS, temperature=PLAN_TEMP)
    return extract_text(resp)


# =============================
# 7) Core pipeline functions
# =============================
def make_card(row, cmap: dict) -> dict:
    card = {k: as_str(row.get(cmap.get(k, k), "—")) for k in CANON}
    urls = split_urls(card.get("Web address(es)", ""))
    pmids = [f"https://pubmed.ncbi.nlm.nih.gov/{p}/" for p in split_pmids(card.get("PMID(s)", ""))]
    card["_citations"] = [u for u in (urls + pmids) if u]
    return card


def enforce_single_uid_marker(paragraph: str, uid: str) -> str:
    txt = paragraph.strip()
    txt = re.sub(r"\s+", " ", txt).strip()
    txt = re.sub(r"\[\^\s*[A-Za-z0-9._-]+\s*\]", "", txt).strip()
    if not txt.endswith("."):
        txt += "."
    txt += f" [^{uid}]"
    return txt


def row_facts(card):
    return {
        "Submitting ICO": card.get("Submitting ICO", "—"),
        "Lead ICO": card.get("Lead ICO", "—"),
        "Collaborating ICOs/Agencies/Orgs": card.get("Collaborating ICOs/Agencies/Orgs", "—"),
        "Activity Name": card.get("Activity Name", "—"),
        "Activity Description": card.get("Activity Description", "—"),
        "Unique ID": card.get("Unique ID", "—"),
    }


def build_effective_system_text(base_system_text: str, style_override: str) -> str:
    """
    Appends a user-supplied override to the LLM system prompt.
    This changes content/tone/structure, not DOCX formatting.
    """
    o = (style_override or "").strip()
    if not o:
        return base_system_text
    return base_system_text.rstrip() + "\n\n" + "User override for THIS RUN:\n" + o + "\n"


def generate_row_paragraph(system_text: str, card: dict) -> str:
    uid = card.get("Unique ID", "—")
    instr = (
        "- Using ONLY these fields, write a 3–5 sentence paragraph in NIH house style.\n"
        "- Include: Submitting ICO, Lead ICO, Collaborators, Activity Name, and the essence of Activity Description.\n"
        "- Do NOT include Activity Type or Importance explicitly.\n"
        "- Do NOT include any URLs, PMIDs, tables, lists, JSON, code fences, or metadata. Output pure prose only.\n"
        "- Append a single UID superscript marker for this row at the VERY END of the paragraph, formatted as [^<UID>].\n"
    )
    user = {"role": "user", "content": instr + "\n" + json.dumps(row_facts(card), ensure_ascii=False)}
    resp = call_fmapi(
        ENDPOINT,
        messages=[{"role": "system", "content": system_text}, user],
        max_tokens=MAX_TOKENS_ROW,
        temperature=TEMPERATURE,
    )
    txt = extract_text(resp)
    return enforce_single_uid_marker(txt, uid)


def top_participating_ics(cards, k=8):
    counter = collections.Counter()
    for c in cards:
        for key in ("Submitting ICO", "Lead ICO"):
            val = (c.get(key) or "—").strip()
            if val and val != "—":
                counter[val] += 1
    return [name for name, _ in counter.most_common(k)]


def sanitize_intro(md: str) -> str:
    md = re.sub(r"^\s{0,3}#{1,6}\s+.*$", "", md, flags=re.MULTILINE)
    md = re.sub(r"\n{2,}", "\n\n", md)
    md = re.sub(r"[ \t]+\n", "\n", md)
    return md.strip()


def generate_intro(system_text: str, cards: list[dict], uid_index: dict, field_value: str, activity_type_value: str):
    payload = {
        "meta": {"field_filter": field_value, "activity_type_filter": activity_type_value, "fiscal_years": []},
        "counts": {"rows": len(cards), "unique_uids": len(uid_index)},
        "institutes_top": top_participating_ics(cards, k=8),
        "allowed_uids": sorted(uid_index.keys()),
    }

    instr = (
        f"- Write {INTRO_MIN_PARAS} to {INTRO_TARGET_MAX} long, substantive paragraphs for the Introduction of an NIH Triennial report.\n"
        "- Use only the facts in the provided payload (meta, counts, top institutes, and allowed_uids).\n"
        "- Do not invent fiscal years; if fiscal_years is empty, do not mention an FY range.\n"
        "- Discuss scientific aims, collaboration patterns, infrastructure/resources, equity/access considerations, translational impact, and implementation context.\n"
        "- Include at least four UID markers overall to anchor claims, formatted as [^<UID>].\n"
        "- You may only use UID markers from allowed_uids; do not create new UIDs.\n"
        "- No bullets; output clean multi-paragraph Markdown prose.\n"
        "- No URLs/PMIDs/JSON/metadata; output pure prose paragraphs only.\n"
        f"- Each paragraph must be at least {INTRO_MIN_WORDS} words.\n"
    )

    content = instr + "\n" + json.dumps(payload, ensure_ascii=False)
    resp = call_fmapi(
        ENDPOINT,
        messages=[{"role": "system", "content": system_text}, {"role": "user", "content": content}],
        max_tokens=MAX_TOKENS_INTRO,
        temperature=TEMPERATURE,
    )
    txt = sanitize_intro(extract_text(resp))

    attempts = 0
    while not _intro_meets_shape(txt, INTRO_MIN_PARAS, INTRO_MIN_WORDS, INTRO_TARGET_MAX) and attempts < INTRO_RETRY_LIMIT:
        attempts += 1
        revision = (
            "REVISION REQUEST:\n"
            f"- Must contain between {INTRO_MIN_PARAS} and {INTRO_TARGET_MAX} paragraphs.\n"
            f"- Each paragraph must be at least {INTRO_MIN_WORDS} words.\n"
            "- Include at least four UID markers total, using ONLY allowed_uids.\n"
            "- Do not add headings or bullet points.\n"
            "- Output only the revised multi-paragraph text.\n\n"
            "CURRENT TEXT:\n"
            f"{txt}\n"
        )
        resp2 = call_fmapi(
            ENDPOINT,
            messages=[
                {"role": "system", "content": system_text},
                {"role": "user", "content": content},
                {"role": "user", "content": revision},
            ],
            max_tokens=MAX_TOKENS_INTRO,
            temperature=TEMPERATURE,
        )
        txt = sanitize_intro(extract_text(resp2))

    return txt


def generate_summary(system_text: str, cards: list[dict], uid_index: dict, field_value: str, activity_type_value: str) -> str:
    payload = {
        "meta": {"field_filter": field_value, "activity_type_filter": activity_type_value, "fiscal_years": []},
        "counts": {"rows": len(cards), "unique_uids": len(uid_index)},
        "institutes_top": top_participating_ics(cards, k=8),
        "allowed_uids": sorted(uid_index.keys()),
    }

    instr = (
        "- Write a concise Summary for an NIH Triennial report.\n"
        "- 2 to 3 paragraphs total.\n"
        "- Use ONLY the provided payload.\n"
        "- Do not invent fiscal years; if fiscal_years is empty, do not mention an FY range.\n"
        "- Include at least two UID markers overall, formatted as [^<UID>], using ONLY allowed_uids.\n"
        "- No bullets; no headings; no URLs/PMIDs/JSON/metadata.\n"
        "- Output pure prose paragraphs only.\n"
    )

    content = instr + "\n" + json.dumps(payload, ensure_ascii=False)
    resp = call_fmapi(
        ENDPOINT,
        messages=[{"role": "system", "content": system_text}, {"role": "user", "content": content}],
        max_tokens=MAX_TOKENS_SUMMARY,
        temperature=TEMPERATURE,
    )
    return sanitize_intro(extract_text(resp))


def pick_sections(card: dict) -> list[str]:
    text = " ".join([
        card.get("Activity Name", ""),
        card.get("Activity Description", ""),
        card.get("Activity Type", ""),
        card.get("Importance", ""),
        card.get("Collaborating ICOs/Agencies/Orgs", ""),
    ]).lower()

    hits = set()

    def has_any(keys):
        return any(k in text for k in keys)

    if has_any(["image", "imaging", "radiology", "ai", "ml", "deep learning", "pet", "mri", "ct", "midrc"]):
        hits.add("Advanced Imaging & AI Tools")
    if has_any(["combination", "combo", "targeted", "inhibitor", "kinase", "precision", "molecularly targeted", "combo therapy"]):
        hits.add("Combination & Targeted Therapies")
    if has_any(["commons", "repository", "portal", "database", "computational", "cloud", "workflow", "data hub", "registry"]):
        hits.add("Data Commons and Computational Resources")
    if has_any(["environmental", "exposure", "toxic", "pollut", "air", "water", "environment", "occupational"]):
        hits.add("Environmental Health and Cancer")
    if has_any(["epidemiology", "surveillance", "registry", "incidence", "prevalence", "cohort", "population"]):
        hits.add("Epidemiology & Surveillance")
    if has_any(["genetic", "genome", "omics", "transcript", "proteomic", "epigen", "cell", "mechanism", "mutation", "gene"]):
        hits.add("Genetics, Cell Biology, and -Omics")
    if has_any(["immunotherapy", "checkpoint", "t cell", "car-t", "immune", "nk cell", "neoantigen"]):
        hits.add("Immunotherapy")
    if has_any(["nutrition", "diet", "exercise", "symptom", "quality of life", "palliative", "cachexia"]):
        hits.add("Nutrition & Symptom Management")
    if has_any(["prevent", "screen", "risk reduction", "vaccin", "hpv", "self-collection"]):
        hits.add("Preventive Interventions")
    if has_any(["recalcitrant", "hard-to-treat", "glioblastoma", "pancreatic", "rare", "refractory"]):
        hits.add("Recalcitrant & Hard-to-Treat Cancer Research")
    if has_any(["screen", "early detection", "biomarker", "liquid biopsy", "mcde"]):
        hits.add("Screening & Early Detection")
    if has_any(["microenvironment", "stroma", "stromal", "macrophage", "myeloid", "tme", "caf"]):
        hits.add("Tumor Microenvironment & Immunology")

    if not hits:
        hits.add("Genetics, Cell Biology, and -Omics")

    return [s for s in SECTION_ORDER if s in hits]


def section_synthesis(system_text: str, section_name: str, uids: list[str], uid_index: dict):
    instr = (
        "- Write one or two cohesive synthesis paragraphs for the section title below.\n"
        "- Use ONLY the provided row facts.\n"
        "- Focus on scientific themes, methods, and collaboration patterns.\n"
        "- Do NOT repeat individual activity descriptions verbatim.\n"
        "- Do NOT mention Activity Type or Importance labels.\n"
        "- Optionally include ONE UID marker at the end if a concrete example strengthens the synthesis.\n"
        "- No bullets, no headings, no URLs, no metadata.\n"
    )

    rows = []
    for u in uids[:6]:
        c = uid_index[u]
        rows.append({
            "UID": u,
            "Submitting ICO": c.get("Submitting ICO", "—"),
            "Lead ICO": c.get("Lead ICO", "—"),
            "Activity Name": c.get("Activity Name", "—"),
            "Activity Description": (c.get("Activity Description", "—")[:400]),
        })
    payload = {"section": section_name, "rows": rows}

    resp = call_fmapi(
        ENDPOINT,
        messages=[
            {"role": "system", "content": system_text},
            {"role": "user", "content": instr + "\n" + json.dumps(payload, ensure_ascii=False)},
        ],
        max_tokens=MAX_TOKENS_SYN,
        temperature=TEMPERATURE,
    )
    txt = extract_text(resp)
    txt = re.sub(r"^\s{0,3}#{1,6}\s+.*$", "", txt, flags=re.MULTILINE).strip()
    return txt


def assemble_markdown(summary_text: str, intro_text: str, section_to_uids: dict, section_syn: dict, uid_to_paragraph: dict) -> str:
    md_parts = []
    md_parts.append("## Summary\n")
    md_parts.append(summary_text.strip() + "\n")
    md_parts.append("\n## Introduction\n")
    md_parts.append(intro_text.strip() + "\n")

    written_uids = set()
    for sec in SECTION_ORDER:
        uids = section_to_uids.get(sec, [])
        if not uids:
            continue

        md_parts.append(f"\n## {sec}\n")
        md_parts.append(", ".join(uids) + "\n")

        syn = (section_syn.get(sec, "") or "").strip()
        if syn:
            md_parts.append(syn + "\n")

        for uid in uids:
            if uid in written_uids:
                continue
            written_uids.add(uid)

            para = (uid_to_paragraph.get(uid) or "").strip()
            if not para:
                continue

            md_parts.append(f"\n**UID {uid}**\n")
            md_parts.append(para.strip() + "\n")

    return "\n".join(md_parts).strip()


def ensure_pandoc():
    pandoc = Path("/tmp/pandoc/bin/pandoc")
    if pandoc.exists():
        return str(pandoc)

    install_sh = r"""
set -euo pipefail
PVER="3.3"
WORKDIR="/tmp/pandoc"
mkdir -p "$WORKDIR"
cd "$WORKDIR"
curl -L -o pandoc.tgz "https://github.com/jgm/pandoc/releases/download/${PVER}/pandoc-${PVER}-linux-amd64.tar.gz"
tar -xzf pandoc.tgz
mkdir -p "$WORKDIR/bin"
cp "pandoc-${PVER}/bin/pandoc" "$WORKDIR/bin/pandoc"
chmod +x "$WORKDIR/bin/pandoc"
"""
    subprocess.run(["bash", "-lc", install_sh], check=True)
    pandoc_bin = Path("/tmp/pandoc/bin/pandoc")
    if not pandoc_bin.exists():
        raise RuntimeError("Pandoc installation failed.")
    return str(pandoc_bin)


def export_docx(md_text: str, out_dir: str, field_value: str, activity_type_value: str, lua_enabled: bool) -> str:
    pandoc = ensure_pandoc()

    field_part = _safe_filename(field_value)
    atype_part = _safe_filename(activity_type_value)
    docx_path = str(Path(out_dir) / f"Triennial_Data_{field_part}_{atype_part}.docx")
    md_path = str(Path(out_dir) / "report.md")
    Path(md_path).write_text(md_text, encoding="utf-8")

    env = os.environ.copy()
    env["PATH"] = f"/tmp/pandoc/bin:{env.get('PATH', '')}"

    cmd = [
        pandoc, md_path,
        "-o", docx_path,
        "--from", "markdown+footnotes+autolink_bare_uris",
        "--to", "docx",
        "--wrap=none",
        "--standalone",
    ]

    if Path(REFERENCE_DOCX_LOCAL).exists():
        cmd += ["--reference-doc", REFERENCE_DOCX_LOCAL]

    if lua_enabled and Path(LUA_FILTER_LOCAL).exists():
        cmd += ["--lua-filter", LUA_FILTER_LOCAL]

    p = subprocess.run(cmd, env=env, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(
            "Pandoc failed.\n"
            f"Return code: {p.returncode}\n\n"
            "STDOUT:\n" + (p.stdout or "(empty)") + "\n\n"
            "STDERR:\n" + (p.stderr or "(empty)") + "\n"
        )

    return docx_path


def publish_for_download(local_docx_path: str, out_dbfs_dir: str) -> str:
    dbfs_mkdirs(out_dbfs_dir)
    filename = Path(local_docx_path).name
    target = f"{out_dbfs_dir}/{filename}"
    data = Path(local_docx_path).read_bytes()
    dbfs_put_large(target, data, overwrite=True)

    rel = target.replace("dbfs:/FileStore/", "")
    return f"/files/{rel}"


def maybe_copy_to_volume(local_docx_path: str, volume_dir: str):
    vol = Path(volume_dir)
    if not vol.exists():
        raise RuntimeError(f"Volume directory does not exist in this App container: {volume_dir}")
    if not vol.is_dir():
        raise RuntimeError(f"Volume path is not a directory: {volume_dir}")
    target = vol / Path(local_docx_path).name
    shutil.copyfile(local_docx_path, str(target))


def write_style_prompt_to_dbfs(style_prompt_dbfs_path: str, system_text: str):
    """
    Optional: persist the effective system prompt back into DBFS style_prompt.json.
    Keeps the same JSON structure {"content": "..."}.
    """
    host = get_workspace_host()
    url = f"{host}/api/2.0/dbfs/put"

    payload_obj = {"content": system_text}
    payload_bytes = json.dumps(payload_obj, ensure_ascii=False, indent=2).encode("utf-8")

    # dbfs/put has a 1MB limit; this prompt should be small. If you ever exceed it, switch to create/add-block.
    r = requests.post(
        url,
        headers=auth_headers(),
        json={
            "path": dbfs_norm(style_prompt_dbfs_path),
            "contents": base64.b64encode(payload_bytes).decode("utf-8"),
            "overwrite": True,
        },
        timeout=30,
    )
    r.raise_for_status()


# =============================
# 9) UI: Inputs + Load button
# =============================
with st.expander("Inputs", expanded=True):
    c1, c2 = st.columns(2)

    with c1:
        excel_dbfs = st.text_input("Excel (DBFS path)", value=DEFAULT_EXCEL_DBFS)
        style_prompt_dbfs = st.text_input("Style prompt (DBFS path)", value=DEFAULT_STYLE_PROMPT_DBFS)
        reference_docx_dbfs = st.text_input("Reference DOCX (DBFS path)", value=DEFAULT_REFERENCE_DOCX_DBFS)

    with c2:
        working_out_dbfs = st.text_input("Working output dir (DBFS path)", value=DEFAULT_WORKING_OUT_DBFS)
        volume_out_dir = st.text_input("Final output volume dir (optional)", value=DEFAULT_VOLUME_OUT_DIR)
        copy_to_volume = st.checkbox("Also copy final DOCX into Volume directory", value=False)

    use_lua_filter = st.checkbox("Use LUA page-break filter (optional)", value=False)
    st.caption("Tip: After changing inputs, click 'Load Inputs' to restage files and refresh dropdown values.")
    load_inputs = st.button("Load Inputs")

if "inputs_loaded" not in st.session_state:
    st.session_state.inputs_loaded = False

if load_inputs or not st.session_state.inputs_loaded:
    with st.spinner("Loading inputs (staging DBFS files)…"):
        stage_assets_or_stop(
            excel_dbfs=excel_dbfs.strip(),
            style_prompt_dbfs=style_prompt_dbfs.strip(),
            reference_docx_dbfs=reference_docx_dbfs.strip(),
            lua_filter_dbfs=DEFAULT_LUA_FILTER_DBFS,
            square_filter_dbfs=DEFAULT_SQUARE_FILTER_DBFS,
        )
        try:
            load_excel.clear()
            load_system_text.clear()
        except Exception:
            pass
        st.session_state.inputs_loaded = True

system_text_base = load_system_text(STYLE_PROMPT_LOCAL)
df = load_excel(EXCEL_LOCAL)

field_col = resolve_column(df, FIELD_COL)
atype_col = resolve_column(df, ACTIVITY_TYPE_COL)

# =============================
# 9.1) Cascaded dropdowns (side-by-side)
# =============================
field_values = dropdown_values(df, field_col)

c_left, c_right = st.columns(2)
with c_left:
    selected_field = st.selectbox(
        "Field",
        field_values,
        index=field_values.index("Cancer") if "Cancer" in field_values else 0,
        key="field_select",
    )

df_field = df[df[field_col].astype(str) == str(selected_field)].copy()
atype_values = dropdown_values(df_field, atype_col)

with c_right:
    selected_activity_type = st.selectbox(
        "Activity Type",
        atype_values,
        index=0 if len(atype_values) > 0 else 0,
        key="atype_select",
    )

st.divider()

# =============================
# 9.2) Preflight + confirmation gate
# =============================
with st.expander("Preflight (review preview before generating)", expanded=True):
    style_override = st.text_area(
        "Optional: style / tone / structure requests (applied to this run)",
        value="",
        height=120,
        placeholder="Example: use shorter sentences; avoid jargon; emphasize collaboration and translational impact.",
        key="style_override",
    )

    persist_style_override = st.checkbox(
        "Also update style_prompt.json in DBFS using the override (optional)",
        value=False,
        help="If checked, the effective system prompt for this run will be written back to DBFS style_prompt.json.",
    )

    docx_color_text = st.text_input(
        "Optional: DOCX primary text color (formatting) — e.g., blue or #0000ff",
        value="",
        help="This changes Word formatting (unlike LLM prompting). Examples: blue, #0000ff, 0000ff, rgb(0,0,255).",
    )

    build_plan = st.button("Build Plan", type="secondary")

    if "plan_ready" not in st.session_state:
        st.session_state.plan_ready = False
    if "plan_text" not in st.session_state:
        st.session_state.plan_text = ""
    if "plan_counts" not in st.session_state:
        st.session_state.plan_counts = {}
    if "plan_uids" not in st.session_state:
        st.session_state.plan_uids = []

    if build_plan:
        if not selected_activity_type:
            st.error("Cannot build preview because Activity Type is empty for the selected Field.")
            st.stop()

        filtered_for_plan = df[
            (df[field_col].astype(str) == str(selected_field))
            & (df[atype_col].astype(str) == str(selected_activity_type))
        ].copy()
        filtered_for_plan = filtered_for_plan.fillna("—")

        if len(filtered_for_plan) == 0:
            st.warning("No rows match the selected filters.")
            st.session_state.plan_ready = False
        else:
            cmap = resolve_map(df.columns)
            cards_for_plan = [make_card(r, cmap) for _, r in filtered_for_plan.iterrows()]

            uid_index_for_plan = {}
            for c in cards_for_plan:
                uid = c.get("Unique ID", "—")
                if uid and uid != "—":
                    uid_index_for_plan[uid] = c

            uids = list(uid_index_for_plan.keys())
            counts = {"filtered_rows": int(len(filtered_for_plan)), "unique_uids": int(len(uids))}

            st.write(
                f"Preview: {counts['filtered_rows']} filtered rows, {counts['unique_uids']} unique UIDs "
                f"for Field='{selected_field}' and Activity Type='{selected_activity_type}'."
            )
            st.caption("First UIDs (up to 30):")
            st.code(", ".join(uids[:30]) if uids else "(none)")

            eff_system_text = build_effective_system_text(system_text_base, style_override)

            with st.spinner("Generating preview (LLM)…"):
                plan_txt = generate_plan(
                    field_value=str(selected_field),
                    activity_type_value=str(selected_activity_type),
                    uid_list=uids,
                    counts=counts,
                    style_override=style_override,
                )

            st.subheader("preview (LLM-generated)")
            st.write(plan_txt)

            st.session_state.plan_text = plan_txt
            st.session_state.plan_counts = counts
            st.session_state.plan_uids = uids
            st.session_state.plan_ready = True

    proceed = st.checkbox(
        "Yes — proceed to generate using this plan",
        value=False,
        disabled=not st.session_state.plan_ready,
    )

st.divider()
generate = st.button("Generate Report", type="primary", disabled=not (st.session_state.plan_ready and proceed))

narration_placeholder = st.empty()
st.caption("Live narration updates here (replaces in place).")


def set_narration(stage: str, detail: str, context: dict):
    try:
        line = narrator_line(stage=stage, detail=detail, context=context)
        ts = time.strftime("%H:%M:%S")
        narration_placeholder.info(f"[{ts}] {line}")
    except Exception:
        ts = time.strftime("%H:%M:%S")
        narration_placeholder.info(f"[{ts}] {detail}")


# =============================
# 10) Run pipeline
# =============================
if generate:
    progress = st.progress(0, text="Starting…")
    status = st.empty()

    ctx = {"field": str(selected_field), "activity_type": str(selected_activity_type), "counts": {}}
    narration_every_n = int(NARRATE_EVERY_N_DEFAULT)

    if not selected_activity_type:
        st.error("Cannot generate report because Activity Type is empty for the selected Field.")
        st.stop()

    # Build effective system text for this run (LLM content control)
    effective_system_text = build_effective_system_text(system_text_base, style_override)

    # Optional: persist effective style prompt to DBFS + restage for the run
    if persist_style_override and style_override.strip():
        try:
            write_style_prompt_to_dbfs(style_prompt_dbfs.strip(), effective_system_text)
            # Restage style prompt into local, so load_system_text reads the updated content in future runs
            data = dbfs_read_all(style_prompt_dbfs.strip())
            if data:
                dbfs_write_file(STYLE_PROMPT_LOCAL, data)
            st.success("style_prompt.json updated in DBFS and re-staged for this run.")
        except Exception as e:
            st.warning(f"Could not update style_prompt.json in DBFS (continuing without persisting): {e}")

    # DOCX formatting color override (actual Word styling)
    docx_primary_rgb = parse_hex_color(docx_color_text)

    try:
        set_narration("start", "Initializing generation pipeline.", ctx)

        status.write("Filtering rows…")
        set_narration("filter", f"Filtering dataset for Field='{selected_field}' and Activity Type='{selected_activity_type}'.", ctx)

        filtered = df[
            (df[field_col].astype(str) == str(selected_field))
            & (df[atype_col].astype(str) == str(selected_activity_type))
        ].copy()
        filtered = filtered.fillna("—")

        st.write(f"Filtered rows: {len(filtered)}")
        if len(filtered) == 0:
            set_narration("filter", "No matching rows found for the selected filters.", ctx)
            st.warning("No rows match the selected filters.")
            st.stop()

        progress.progress(0.10, text="Preparing cards…")
        set_narration("cards", "Normalizing columns and preparing row cards.", ctx)

        cmap = resolve_map(df.columns)
        cards = [make_card(r, cmap) for _, r in filtered.iterrows()]

        uid_index = {}
        for c in cards:
            uid = c.get("Unique ID", "—")
            if uid and uid != "—":
                uid_index[uid] = c

        if not uid_index:
            set_narration("cards", "No valid Unique IDs found in filtered data.", ctx)
            st.error("No valid Unique IDs found in the filtered rows.")
            st.stop()

        ctx["counts"] = {"filtered_rows": int(len(filtered)), "unique_uids": int(len(uid_index))}

        progress.progress(0.20, text="Generating row paragraphs…")
        set_narration("rows", f"Generating narrative paragraphs for {len(uid_index)} activities.", ctx)

        uid_to_paragraph = {}
        total = len(uid_index)

        for i, (uid, card) in enumerate(uid_index.items(), 1):
            status.write(f"Generating row paragraph {i}/{total}: {uid}")

            if i == 1 or i == total or (i % narration_every_n == 0):
                set_narration("rows", f"Drafting activity narrative {i} of {total} (UID {uid}).", ctx)

            with st.spinner(f"Model is thinking for UID {uid}…"):
                para = generate_row_paragraph(effective_system_text, card)

            uid_to_paragraph[uid] = para

            if SHOW_PARTIAL_OUTPUT:
                st.write(para)

            progress.progress(0.20 + 0.25 * (i / total), text=f"Row paragraphs: {i}/{total}")

        progress.progress(0.50, text="Routing to sections…")
        set_narration("sections", "Routing activities into report sections.", ctx)

        section_to_uids = {sec: [] for sec in SECTION_ORDER}
        for uid, card in uid_index.items():
            for sec in pick_sections(card):
                section_to_uids.setdefault(sec, []).append(uid)

        progress.progress(0.58, text="Generating Summary…")
        set_narration("summary", "Generating the executive Summary section.", ctx)
        with st.spinner("Model is thinking for the Summary…"):
            summary_text = generate_summary(effective_system_text, cards, uid_index, selected_field, selected_activity_type)

        progress.progress(0.65, text="Generating Introduction…")
        set_narration("intro", "Generating the multi-paragraph Introduction.", ctx)
        with st.spinner("Model is thinking for the Introduction…"):
            intro_text = generate_intro(effective_system_text, cards, uid_index, selected_field, selected_activity_type)

        progress.progress(0.78, text="Generating section syntheses…")
        set_narration("synth", "Generating section-level syntheses.", ctx)

        section_syn = {}
        secs_with_uids = [sec for sec in SECTION_ORDER if section_to_uids.get(sec)]
        denom = max(1, len(secs_with_uids))

        done = 0
        for sec in SECTION_ORDER:
            uids = section_to_uids.get(sec, [])
            if not uids:
                continue

            done += 1
            set_narration("synth", f"Writing synthesis for section {done} of {denom}: {sec}.", ctx)
            with st.spinner(f"Model is thinking for section: {sec}…"):
                section_syn[sec] = section_synthesis(effective_system_text, sec, uids, uid_index)

            progress.progress(0.78 + 0.10 * (done / denom), text=f"Section syntheses: {done}/{denom}")

        progress.progress(0.90, text="Assembling markdown…")
        set_narration("assemble", "Assembling report markdown and integrating generated components.", ctx)

        md = assemble_markdown(summary_text, intro_text, section_to_uids, section_syn, uid_to_paragraph)

        set_narration("footnotes", "Converting UID markers into numeric Word footnotes.", ctx)
        md_numeric, footnotes = build_footnotes_from_uid_markers(md, uid_index)
        md = md_numeric + "\n\n" + footnotes + "\n"

        progress.progress(0.93, text="Exporting DOCX…")
        set_narration("docx", "Exporting the report to DOCX via Pandoc.", ctx)

        with st.spinner("Building DOCX (Pandoc)…"):
            docx_path = export_docx(md, LOCAL_OUT_DIR, selected_field, selected_activity_type, lua_enabled=use_lua_filter)

        # ✅ Apply DOCX primary color override here (this is what makes text blue)
        if docx_primary_rgb is not None and DOCX_AVAILABLE:
            set_narration("format", "Applying DOCX primary text color formatting.", ctx)
            with st.spinner("Applying DOCX text color…"):
                apply_primary_color_to_docx(docx_path, docx_primary_rgb)
        elif docx_primary_rgb is not None and not DOCX_AVAILABLE:
            st.warning(
                "DOCX color override requested, but python-docx is not available in this environment. "
                 "The report was generated successfully without color formatting."
                )


        if copy_to_volume:
            set_narration("volume", "Copying the DOCX into the configured Volume directory.", ctx)
            with st.spinner("Copying to Volume…"):
                maybe_copy_to_volume(docx_path, volume_out_dir)

        progress.progress(0.97, text="Publishing for download…")
        set_narration("publish", "Publishing the DOCX to DBFS FileStore for download.", ctx)

        with st.spinner("Publishing file to DBFS…"):
            url = publish_for_download(docx_path, working_out_dbfs.strip())

        progress.progress(1.0, text="Done.")
        status.success("Report generated successfully.")
        set_narration("done", "Generation complete. The report is ready for download.", ctx)

        st.markdown("### Download")
        docx_bytes = Path(docx_path).read_bytes()
        st.download_button(
            label="Download DOCX",
            data=docx_bytes,
            file_name=Path(docx_path).name,
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )

        full_url = f"{get_workspace_host()}{url}"
        st.link_button("Open FileStore link", full_url)
        st.caption(url)

        with st.expander("Technical details"):
            st.write("DOCX local:", docx_path)
            st.write("DOCX size (bytes):", Path(docx_path).stat().st_size)
            st.write("Published URL (relative):", url)
            st.write("Published URL (absolute):", full_url)
            st.write("Endpoint:", ENDPOINT)
            st.write("LUA filter enabled:", bool(use_lua_filter))
            st.write("Style override persisted:", bool(persist_style_override and style_override.strip()))
            st.write("DOCX primary color override:", docx_primary_rgb)

            if copy_to_volume:
                st.write("Copied to Volume dir:", volume_out_dir)

    except Exception as e:
        progress.progress(1.0, text="Failed.")
        set_narration("error", f"Generation failed: {e}", ctx)
        st.error(f"Generation failed: {e}")
        st.stop()
